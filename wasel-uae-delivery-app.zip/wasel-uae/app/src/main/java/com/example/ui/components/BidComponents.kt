package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AcUnit
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.LocalShipping
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.TwoWheeler
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.Bid
import com.example.model.BidStatus
import com.example.model.DriverProfile
import com.example.model.VehicleType
import com.example.ui.theme.WaselEmerald
import com.example.ui.theme.WaselGold
import com.example.ui.theme.WaselNavy

/**
 * يعرض بطاقة السائق المعتمد مع التقييم وعدد الرحلات المنجزة ورقم اللوحة وحالة أساطيل.
 * يستخدم في صفحة تفاصيل الطلب وداخل بطاقات العروض التنافسية.
 */
@Composable
fun DriverInfoBlock(
    driver: DriverProfile,
    showContactAction: Boolean = false,
    onCallDriver: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // دائرة الأحرف الأولى من اسم الكابتن
        Box(
            modifier = Modifier
                .size(48.dp)
                .clip(CircleShape)
                .background(WaselNavy.copy(alpha = 0.1f)),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = driver.avatarLetter,
                color = WaselNavy,
                fontWeight = FontWeight.ExtraBold,
                fontSize = 20.sp
            )
        }

        Spacer(modifier = Modifier.width(12.dp))

        Column(modifier = Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = driver.nameAr,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    color = Color(0xFF0F172A)
                )
                Spacer(modifier = Modifier.width(6.dp))
                if (driver.isAsateelVerified) {
                    Icon(
                        imageVector = Icons.Default.Verified,
                        contentDescription = null,
                        tint = WaselEmerald,
                        modifier = Modifier.size(14.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(4.dp))

            // صف التقييم وعدد الرحلات
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.Star,
                    contentDescription = null,
                    tint = WaselGold,
                    modifier = Modifier.size(12.dp)
                )
                Spacer(modifier = Modifier.width(2.dp))
                Text(
                    text = String.format("%.2f", driver.rating),
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFFB45309)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = "(${driver.reviewsCount} تقييم)",
                    fontSize = 10.sp,
                    color = Color(0xFF64748B)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "• ${driver.completedTripsCount} رحلة منجزة",
                    fontSize = 10.sp,
                    color = Color(0xFF64748B)
                )
            }

            Spacer(modifier = Modifier.height(4.dp))

            // نوع المركبة ورقم اللوحة
            Row(verticalAlignment = Alignment.CenterVertically) {
                VehicleBadgeCompact(vehicleType = driver.vehicleType)
                Spacer(modifier = Modifier.width(8.dp))
                Surface(
                    color = Color(0xFFF1F5F9),
                    shape = RoundedCornerShape(4.dp)
                ) {
                    Text(
                        text = "اللوحة: ${driver.vehiclePlate}",
                        fontSize = 10.sp,
                        color = Color(0xFF334155),
                        fontWeight = FontWeight.Medium,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }
        }

        if (showContactAction && onCallDriver != null) {
            Button(
                onClick = onCallDriver,
                colors = ButtonDefaults.buttonColors(containerColor = WaselEmerald),
                shape = RoundedCornerShape(8.dp),
                contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 10.dp, vertical = 4.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Phone,
                    contentDescription = null,
                    tint = Color.White,
                    modifier = Modifier.size(14.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text("اتصال", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
fun VehicleBadgeCompact(vehicleType: VehicleType, modifier: Modifier = Modifier) {
    val icon = when (vehicleType) {
        VehicleType.INSULATED_BIKE -> Icons.Default.TwoWheeler
        VehicleType.COOLING_VAN -> Icons.Default.AcUnit
        else -> Icons.Default.LocalShipping
    }
    Surface(
        color = Color(0xFFEFF6FF),
        shape = RoundedCornerShape(4.dp),
        modifier = modifier
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = Color(0xFF1D4ED8),
                modifier = Modifier.size(12.dp)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
                text = vehicleType.badgeAr,
                fontSize = 10.sp,
                color = Color(0xFF1D4ED8),
                fontWeight = FontWeight.SemiBold
            )
        }
    }
}

/**
 * بطاقة عرض تنافسي مقدّم من السائق على طلبية.
 * تعرض السعر، ETA، ملاحظة الكابتن، وزر قبول العرض (للتاجر).
 */
@Composable
fun BidCard(
    bid: Bid,
    isWinning: Boolean,
    canAccept: Boolean,
    onAccept: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    val containerColor = when {
        bid.status == BidStatus.ACCEPTED -> Color(0xFFECFDF5)
        bid.status == BidStatus.REJECTED -> Color(0xFFF8FAFC)
        isWinning -> Color(0xFFEFF6FF)
        else -> Color.White
    }
    val borderColor = when {
        bid.status == BidStatus.ACCEPTED -> WaselEmerald
        isWinning -> WaselGold
        else -> Color(0xFFE2E8F0)
    }

    Card(
        colors = CardDefaults.cardColors(containerColor = containerColor),
        shape = RoundedCornerShape(14.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, borderColor),
        elevation = CardDefaults.cardElevation(defaultElevation = if (bid.status == BidStatus.ACCEPTED) 4.dp else 1.dp),
        modifier = modifier
            .fillMaxWidth()
            .testTag("card_bid_${bid.id}")
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            DriverInfoBlock(driver = bid.driver)

            Spacer(modifier = Modifier.height(10.dp))

            // صف السعر ومدة الانتظار
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "عرض السعر",
                        fontSize = 10.sp,
                        color = Color(0xFF64748B)
                    )
                    Text(
                        text = "${bid.amountAed.toInt()} د.إ",
                        fontSize = 22.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = if (bid.status == BidStatus.ACCEPTED) WaselEmerald else WaselNavy
                    )
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = "وصول خلال",
                        fontSize = 10.sp,
                        color = Color(0xFF64748B)
                    )
                    Text(
                        text = "${bid.etaMinutes} دقيقة",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF0F172A)
                    )
                }
            }

            if (bid.noteAr.isNotBlank()) {
                Spacer(modifier = Modifier.height(8.dp))
                Surface(
                    color = Color(0xFFF8FAFC),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = bid.noteAr,
                        fontSize = 11.sp,
                        color = Color(0xFF334155),
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                    )
                }
            }

            if (bid.status == BidStatus.ACCEPTED) {
                Spacer(modifier = Modifier.height(10.dp))
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(WaselEmerald.copy(alpha = 0.12f))
                        .padding(horizontal = 10.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.CheckCircle,
                        contentDescription = null,
                        tint = WaselEmerald,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "تم قبول هذا العرض وقفل السعر والمسار بنجاح",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF065F46)
                    )
                }
            } else if (canAccept && onAccept != null) {
                Spacer(modifier = Modifier.height(10.dp))
                Button(
                    onClick = onAccept,
                    colors = ButtonDefaults.buttonColors(containerColor = WaselGold),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "قبول العرض وقفل السعر",
                        color = WaselNavy,
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 13.sp
                    )
                }
            }
        }
    }
}
