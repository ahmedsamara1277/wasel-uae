package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.ChatMessage
import com.example.model.UserRole
import com.example.ui.theme.WaselEmerald
import com.example.ui.theme.WaselGold
import com.example.ui.theme.WaselNavy

/**
 * يعرض محادثة التاجر مع السائق داخل صفحة تفاصيل الطلب.
 * يصنف الرسائل يمين (للتاجر) ويسار (للسائق) مع تنسيق مختلف لإشعارات النظام.
 */
@Composable
fun ChatThread(
    messages: List<ChatMessage>,
    modifier: Modifier = Modifier
) {
    LazyColumn(
        modifier = modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        items(messages, key = { it.id }) { msg ->
            ChatBubble(message = msg)
        }
    }
}

@Composable
fun ChatBubble(message: ChatMessage, modifier: Modifier = Modifier) {
    if (message.isSystemNotice) {
        // إشعار النظام: شريط مركزي مميز
        Surface(
            color = WaselGold.copy(alpha = 0.12f),
            shape = RoundedCornerShape(10.dp),
            modifier = modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .width(3.dp)
                        .height(20.dp)
                        .clip(RoundedCornerShape(2.dp))
                        .background(WaselGold)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                    Text(
                        text = message.senderName,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF92400E)
                    )
                    Text(
                        text = message.messageText,
                        fontSize = 12.sp,
                        color = Color(0xFF451A03),
                        fontWeight = FontWeight.Medium
                    )
                }
            }
        }
        return
    }

    val isMerchant = message.senderRole == UserRole.MERCHANT
    val bubbleColor = if (isMerchant) WaselNavy else WaselEmerald
    val textColor = Color.White
    val authorColor = if (isMerchant) WaselGold else Color(0xFFD1FAE5)

    Row(
        modifier = modifier.fillMaxWidth(),
        horizontalArrangement = if (isMerchant) Arrangement.Start else Arrangement.End
    ) {
        Surface(
            color = bubbleColor,
            shape = RoundedCornerShape(
                topStart = 14.dp,
                topEnd = 14.dp,
                bottomEnd = if (isMerchant) 14.dp else 4.dp,
                bottomStart = if (isMerchant) 4.dp else 14.dp
            ),
            modifier = Modifier.fillMaxWidth(0.82f).testTag("bubble_${message.id}")
        ) {
            Column(modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)) {
                Text(
                    text = message.senderName,
                    fontSize = 10.sp,
                    fontWeight = FontWeight.Bold,
                    color = authorColor
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = message.messageText,
                    fontSize = 13.sp,
                    color = textColor,
                    style = MaterialTheme.typography.bodyMedium
                )
            }
        }
    }
}
