package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHostState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.model.UserRole
import com.example.ui.components.BidPlacementSheet
import com.example.ui.components.WaselActionSnackbar
import com.example.ui.components.WaselTopBar
import com.example.ui.screens.ComplianceInfoSheet
import com.example.ui.screens.CreateOrderSheet
import com.example.ui.screens.DriverHomeScreen
import com.example.ui.screens.MerchantHomeScreen
import com.example.ui.screens.OrderDetailScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.viewmodel.WaselViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                // ضبط اتجاه الواجهة بالكامل من اليمين لليسار لجميع شاشات التطبيق
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    WaselApp()
                }
            }
        }
    }
}

@Composable
fun WaselApp(viewModel: WaselViewModel = viewModel()) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val navController = rememberNavController()
    val snackbarHostState = remember { SnackbarHostState() }

    // عرض رسالة الإجراء عبر الـ Snackbar عند ظهورها
    LaunchedEffect(uiState.lastActionMessage) {
        val msg = uiState.lastActionMessage
        if (!msg.isNullOrBlank()) {
            snackbarHostState.showSnackbar(msg)
            viewModel.clearActionMessage()
        }
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        snackbarHost = { WaselActionSnackbar(hostState = snackbarHostState) },
        topBar = {
            WaselTopBar(
                currentRole = uiState.currentRole,
                onToggleRole = {
                    viewModel.toggleRole()
                    // عند تبديل الدور ارجع إلى الشاشة الرئيسية
                    navController.popBackStack(WaselRoutes.ROOT, inclusive = false)
                },
                onOpenInfo = { viewModel.openComplianceSheet() }
            )
        }
    ) { innerPadding ->
        Box(modifier = Modifier.fillMaxSize()) {
            NavHost(
                navController = navController,
                startDestination = WaselRoutes.ROOT,
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                // الصفحة الرئيسية — تتغير بحسب الدور النشط
                composable(WaselRoutes.ROOT) {
                    when (uiState.currentRole) {
                        UserRole.MERCHANT -> MerchantHomeScreen(
                            orders = uiState.filteredOrders,
                            selectedCategory = uiState.selectedCategoryFilter,
                            onSelectCategory = { viewModel.setCategoryFilter(it) },
                            onSelectOrder = { id ->
                                viewModel.selectOrder(id)
                                navController.navigate(WaselRoutes.orderDetail(id))
                            },
                            onCreateOrderClick = { viewModel.openCreateOrderSheet() },
                            modifier = Modifier.fillMaxSize()
                        )
                        UserRole.DRIVER -> DriverHomeScreen(
                            orders = uiState.filteredOrders,
                            currentDriver = uiState.currentDriver,
                            selectedCategory = uiState.selectedCategoryFilter,
                            selectedEmirate = uiState.selectedEmirateFilter,
                            onSelectCategory = { viewModel.setCategoryFilter(it) },
                            onSelectEmirate = { viewModel.setEmirateFilter(it) },
                            onSelectOrder = { id ->
                                viewModel.selectOrder(id)
                                navController.navigate(WaselRoutes.orderDetail(id))
                            },
                            modifier = Modifier.fillMaxSize()
                        )
                    }
                }

                // صفحة تفاصيل الطلب
                composable(
                    route = WaselRoutes.ORDER_DETAIL,
                    arguments = listOf(navArgument("orderId") { type = NavType.StringType })
                ) { backStackEntry ->
                    val orderId = backStackEntry.arguments?.getString("orderId")
                    val order = uiState.orders.find { it.id == orderId }
                    if (order == null) {
                        // الطلب غير موجود — ارجع للرئيسية
                        LaunchedEffect(Unit) { navController.popBackStack() }
                        return@composable
                    }

                    OrderDetailScreen(
                        order = order,
                        currentRole = uiState.currentRole,
                        onBack = {
                            viewModel.selectOrder(null)
                            navController.popBackStack()
                        },
                        onAcceptBid = { bidId -> viewModel.acceptBid(order.id, bidId) },
                        onAdvanceStatus = { viewModel.advanceOrderStatus(order.id) },
                        onVerifyPin = { pin -> viewModel.verifyPinAndDeliver(order.id, pin) },
                        onSendChat = { text -> viewModel.sendChatMessage(order.id, text) },
                        onPlaceBidClick = { viewModel.openBidPlacementFor(order.id) },
                        modifier = Modifier.fillMaxSize()
                    )
                }
            }

            // النوافذ المنبثقة المنطقية (Overlays)
            if (uiState.showCreateOrderSheet) {
                CreateOrderSheet(
                    onCalculateFloor = { p, d, c -> viewModel.calculateDynamicFloor(p, d, c) },
                    onCalculateDistance = { p, d -> viewModel.calculateDistance(p, d) },
                    onCalculateTolls = { p, d -> viewModel.calculateTolls(p, d) },
                    onCreateOrder = { title, desc, cat, pe, pl, de, dl, price, express ->
                        val newOrderId = viewModel.createOrder(
                            title, desc, cat, pe, pl, de, dl, price, express
                        )
                        navController.navigate(WaselRoutes.orderDetail(newOrderId))
                    },
                    onDismiss = { viewModel.closeCreateOrderSheet() }
                )
            }

            if (uiState.showComplianceSheet) {
                ComplianceInfoSheet(onDismiss = { viewModel.closeComplianceSheet() })
            }

            if (uiState.showBidPlacementSheet && uiState.selectedOrder != null) {
                val order = uiState.selectedOrder!!
                BidPlacementSheet(
                    suggestedFloorPrice = order.dynamicFloorPriceAed,
                    targetPrice = order.merchantTargetPriceAed,
                    onPlaceBid = { amount, eta, note ->
                        viewModel.placeDriverBid(order.id, amount, eta, note)
                        viewModel.closeBidPlacement()
                    },
                    onDismiss = { viewModel.closeBidPlacement() }
                )
            }
        }
    }
}

object WaselRoutes {
    const val ROOT = "home"
    const val ORDER_DETAIL = "order/{orderId}"
    fun orderDetail(orderId: String) = "order/$orderId"
}
