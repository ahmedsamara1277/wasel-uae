package com.example.model

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CardGiftcard
import androidx.compose.material.icons.filled.Fastfood
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.Pets
import androidx.compose.material.icons.filled.Spa
import androidx.compose.material.icons.filled.Storefront
import androidx.compose.ui.graphics.vector.ImageVector

enum class UserRole {
    MERCHANT, // التاجر / صاحب الطلبية
    DRIVER    // السائق / المندوب
}

enum class OrderCategory(
    val titleAr: String,
    val descriptionAr: String,
    val requiresAC: Boolean,
    val requiresColdStorage: Boolean,
    val requiresLiveAnimalCare: Boolean,
    val requiresSecurePin: Boolean
) {
    GIFTS_PERFUMES(
        titleAr = "هدايا وعطور فاخرة",
        descriptionAr = "توصيل آمن بحرص شديد، تسليم برمز سري PIN وحماية من الحرارة",
        requiresAC = true,
        requiresColdStorage = false,
        requiresLiveAnimalCare = false,
        requiresSecurePin = true
    ),
    PETS_BIRDS(
        titleAr = "طيور وحيوانات أليفة",
        descriptionAr = "نقل مكيف حصراً بالسيارات مع تهوية آمنة وفق اشتراطات البيئة والرفق بالحيوان",
        requiresAC = true,
        requiresColdStorage = false,
        requiresLiveAnimalCare = true,
        requiresSecurePin = false
    ),
    DATES_CHOCOLATE(
        titleAr = "شوكولاتات وتمور وحلويات",
        descriptionAr = "حفظ حراري وتبريد مستمر لمنع ذوبان وتزهير الشوكولاتة والحلويات في الصيف",
        requiresAC = true,
        requiresColdStorage = true,
        requiresLiveAnimalCare = false,
        requiresSecurePin = false
    ),
    FOOD_MEALS(
        titleAr = "أطعمة ووجبات سريعة",
        descriptionAr = "حقائب حرارية معزولة وتوصيل سريع مباشر من المطاعم والمطابخ",
        requiresAC = false,
        requiresColdStorage = false,
        requiresLiveAnimalCare = false,
        requiresSecurePin = false
    ),
    PARCELS_BUSINESS(
        titleAr = "طرود ومستندات تجارية",
        descriptionAr = "شحن تجاري فوري وسريع بين الشركات والمتاجر في كافة الإمارات",
        requiresAC = false,
        requiresColdStorage = false,
        requiresLiveAnimalCare = false,
        requiresSecurePin = false
    ),
    OPEN_ORDER(
        titleAr = "اطلب أي شيء / مهمة خاصة",
        descriptionAr = "شراء بالنيابة أو استلام من موقع مخصص مع تفاوض حر ومباشر",
        requiresAC = false,
        requiresColdStorage = false,
        requiresLiveAnimalCare = false,
        requiresSecurePin = false
    );

    val icon: ImageVector
        get() = when (this) {
            GIFTS_PERFUMES -> Icons.Default.CardGiftcard
            PETS_BIRDS -> Icons.Default.Pets
            DATES_CHOCOLATE -> Icons.Default.Spa
            FOOD_MEALS -> Icons.Default.Fastfood
            PARCELS_BUSINESS -> Icons.Default.Inventory2
            OPEN_ORDER -> Icons.Default.Storefront
        }
}

enum class Emirate(val nameAr: String, val tollName: String?, val baseKmFromDubai: Int) {
    DUBAI("دبي", "بوابات سالك (Salik)", 0),
    ABU_DHABI("أبوظبي", "بوابات درب (Darb)", 140),
    SHARJAH("الشارقة", "سالك الممزر (Salik)", 25),
    AJMAN("عجمان", null, 40),
    UMM_AL_QUWAIN("أم القيوين", null, 65),
    RAS_AL_KHAIMAH("رأس الخيمة", null, 110),
    FUJAIRAH("الفجيرة", null, 125),
    AL_AIN("العين", "بوابات درب (Darb)", 150)
}

enum class VehicleType(val nameAr: String, val badgeAr: String, val isClimateControlled: Boolean, val allowsPets: Boolean) {
    AC_SEDAN("سيارة صالون مكيفة", "مكيفة بالكامل", true, true),
    COOLING_VAN("فان تبريد وتحكم حراري", "تبريد احترافي", true, true),
    INSULATED_BIKE("دراجة بصندوق فايبرجلاس معزول", "عزل حراري", false, false),
    SUV_TRANSPORT("سيارة دفع رباعي / نقل سريع", "مكيفة ورحبة", true, true)
}

data class DriverProfile(
    val id: String,
    val nameAr: String,
    val avatarLetter: String,
    val rating: Double,
    val reviewsCount: Int,
    val completedTripsCount: Int,
    val vehicleType: VehicleType,
    val vehiclePlate: String,
    val isAsateelVerified: Boolean,
    val phoneNumber: String,
    val acceptanceRate: Int = 98
)

enum class BidStatus {
    PENDING,
    ACCEPTED,
    REJECTED
}

data class Bid(
    val id: String,
    val orderId: String,
    val driver: DriverProfile,
    val amountAed: Double,
    val etaMinutes: Int,
    val noteAr: String,
    val timestamp: Long = System.currentTimeMillis(),
    val status: BidStatus = BidStatus.PENDING
)

enum class OrderStatus(val titleAr: String, val stepIndex: Int) {
    WAITING_FOR_BIDS("بانتظار عروض المناديب", 0),
    BID_ACCEPTED("تم قبول العرض وقفل السعر", 1),
    DRIVER_EN_ROUTE_PICKUP("الكابتن في طريقه للاستلام", 2),
    PICKED_UP("تم استلام الشحنة", 3),
    IN_TRANSIT("في الطريق إلى المستلم", 4),
    DELIVERED("تم التسليم والتحقق بنجاح", 5),
    CANCELLED("تم إلغاء الطلب", -1)
}

data class DeliveryOrder(
    val id: String,
    val trackingCode: String,
    val category: OrderCategory,
    val title: String,
    val description: String,
    val pickupEmirate: Emirate,
    val pickupLocation: String,
    val dropoffEmirate: Emirate,
    val dropoffLocation: String,
    val distanceKm: Int,
    val estimatedTollsAed: Double,
    val dynamicFloorPriceAed: Double,
    val merchantTargetPriceAed: Double,
    val agreedPriceAed: Double? = null,
    val deliveryPin: String, // 4-digit verification code e.g. "4829"
    val is247Express: Boolean = true,
    val status: OrderStatus = OrderStatus.WAITING_FOR_BIDS,
    val createdAt: Long = System.currentTimeMillis(),
    val selectedDriver: DriverProfile? = null,
    val bids: List<Bid> = emptyList(),
    val chatMessages: List<ChatMessage> = emptyList()
)

data class ChatMessage(
    val id: String,
    val senderRole: UserRole,
    val senderName: String,
    val messageText: String,
    val timestamp: Long = System.currentTimeMillis(),
    val isSystemNotice: Boolean = false
)
