package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.Gavel
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.DeliveryOrder
import com.example.model.OrderCategory
import com.example.model.OrderStatus
import com.example.ui.components.ClimateBadge
import com.example.ui.theme.WaselEmerald
import com.example.ui.theme.WaselGold
import com.example.ui.theme.WaselNavy

@Composable
fun MerchantHomeScreen(
    orders: List<DeliveryOrder>,
    selectedCategory: OrderCategory?,
    onSelectCategory: (OrderCategory?) -> Unit,
    onSelectOrder: (String) -> Unit,
    onCreateOrderClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Box(modifier = modifier.fillMaxSize()) {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 88.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Hero Banner for Merchant
            item {
                MerchantHeroBanner(onCreateClick = onCreateOrderClick)
            }

            // Category Chips filter
            item {
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "تصنيفات الشحنات في الإمارات",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = WaselNavy
                        )
                        if (selectedCategory != null) {
                            Text(
                                text = "عرض الكل",
                                color = WaselGold,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.clickable { onSelectCategory(null) }
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        FilterChip(
                            selected = selectedCategory == null,
                            onClick = { onSelectCategory(null) },
                            label = { Text("جميع الطلبيات (${orders.size})") },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = WaselNavy,
                                selectedLabelColor = Color.White
                            )
                        )
                        OrderCategory.values().forEach { cat ->
                            FilterChip(
                                selected = selectedCategory == cat,
                                onClick = { onSelectCategory(cat) },
                                leadingIcon = {
                                    Icon(
                                        imageVector = cat.icon,
                                        contentDescription = null,
                                        modifier = Modifier.size(16.dp)
                                    )
                                },
                                label = { Text(cat.titleAr) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = WaselNavy,
                                    selectedLabelColor = Color.White
                                )
                            )
                        }
                    }
                }
            }

            // Section Title
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "الطلبيات النشطة وسوق المزايدة",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = WaselNavy
                    )
                    Text(
                        text = "${orders.size} طلبية",
                        style = MaterialTheme.typography.bodySmall,
                        color = Color(0xFF64748B)
                    )
                }
            }

            if (orders.isEmpty()) {
                item {
                    EmptyOrdersPlaceholder(onCreateClick = onCreateOrderClick)
                }
            } else {
                items(orders, key = { it.id }) { order ->
                    MerchantOrderCard(
                        order = order,
                        onClick = { onSelectOrder(order.id) }
                    )
                }
            }
        }

        // Floating Action Button to create a new delivery order
        ExtendedFloatingActionButton(
            onClick = onCreateOrderClick,
            icon = { Icon(Icons.Default.Add, contentDescription = null, tint = WaselNavy) },
            text = { Text("إنشاء طلبية جديدة ومزايدة", fontWeight = FontWeight.Bold, color = WaselNavy) },
            containerColor = WaselGold,
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(16.dp)
                .testTag("fab_create_order")
        )
    }
}

@Composable
fun MerchantHeroBanner(onCreateClick: () -> Unit) {
    Card(
        colors = CardDefaults.cardColors(containerColor = WaselNavy),
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    color = WaselGold.copy(alpha = 0.2f),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text(
                        text = "المزايدة العكسية والتوصيل الفوري",
                        color = WaselGold,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Shield,
                        contentDescription = null,
                        tint = WaselEmerald,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "قفل السعر والمسار",
                        color = WaselEmerald,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))
            Text(
                text = "اربط تجارتك بأفضل السائقين المعتمدين في الإمارات",
                color = Color.White,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "اطرح شحنتك بالسعر المقترح، ودع المناديب المؤهلين يتنافسون لتقديم أفضل العروض. للمأكولات، الهدايا، العطور، الطيور، والتمور.",
                color = Color(0xFFCBD5E1),
                fontSize = 12.sp,
                lineHeight = 18.sp
            )
        }
    }
}

@Composable
fun MerchantOrderCard(
    order: DeliveryOrder,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        shape = RoundedCornerShape(16.dp),
        modifier = modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .testTag("card_order_${order.id}")
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Header Row: Category Badge & Status Pill
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(WaselNavy.copy(alpha = 0.08f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = order.category.icon,
                            contentDescription = null,
                            tint = WaselNavy,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(
                            text = order.category.titleAr,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp,
                            color = WaselNavy
                        )
                        Text(
                            text = order.trackingCode,
                            color = Color(0xFF64748B),
                            fontSize = 11.sp
                        )
                    }
                }

                // Status Pill
                Surface(
                    color = when (order.status) {
                        OrderStatus.WAITING_FOR_BIDS -> WaselGold.copy(alpha = 0.15f)
                        OrderStatus.BID_ACCEPTED -> Color(0xFF0284C7).copy(alpha = 0.15f)
                        OrderStatus.IN_TRANSIT -> WaselEmerald.copy(alpha = 0.15f)
                        OrderStatus.DELIVERED -> Color(0xFF10B981).copy(alpha = 0.2f)
                        else -> Color(0xFFE2E8F0)
                    },
                    shape = RoundedCornerShape(20.dp)
                ) {
                    Text(
                        text = order.status.titleAr,
                        color = when (order.status) {
                            OrderStatus.WAITING_FOR_BIDS -> Color(0xFFB45309)
                            OrderStatus.BID_ACCEPTED -> Color(0xFF0284C7)
                            OrderStatus.IN_TRANSIT -> Color(0xFF047857)
                            OrderStatus.DELIVERED -> Color(0xFF065F46)
                            else -> Color(0xFF475569)
                        },
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Order Title & Description
            Text(
                text = order.title,
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF0F172A)
            )
            Text(
                text = order.description,
                style = MaterialTheme.typography.bodySmall,
                color = Color(0xFF475569),
                maxLines = 2,
                fontSize = 12.sp,
                modifier = Modifier.padding(top = 2.dp)
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Route visualizer (Pickup -> Dropoff)
            Surface(
                color = Color(0xFFF8FAFC),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .clip(CircleShape)
                                .background(WaselGold)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "من: ${order.pickupEmirate.nameAr} (${order.pickupLocation})",
                            fontSize = 11.sp,
                            color = Color(0xFF334155),
                            fontWeight = FontWeight.Medium
                        )
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .clip(CircleShape)
                                .background(WaselEmerald)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "إلى: ${order.dropoffEmirate.nameAr} (${order.dropoffLocation})",
                            fontSize = 11.sp,
                            color = Color(0xFF334155),
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Badges row: AC requirement + Distance + Tolls
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                ClimateBadge(isCooling = order.category.requiresAC)
                Surface(
                    color = Color(0xFFE2E8F0),
                    shape = RoundedCornerShape(4.dp)
                ) {
                    Text(
                        text = "${order.distanceKm} كم",
                        fontSize = 10.sp,
                        color = Color(0xFF334155),
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
                if (order.estimatedTollsAed > 0) {
                    Surface(
                        color = Color(0xFFFEF3C7),
                        shape = RoundedCornerShape(4.dp)
                    ) {
                        Text(
                            text = "رسوم سالك/درب: ${order.estimatedTollsAed.toInt()} د.إ",
                            fontSize = 10.sp,
                            color = Color(0xFF92400E),
                            fontWeight = FontWeight.SemiBold,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Bottom Action Area: Price & Bidding CTA
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = if (order.agreedPriceAed != null) "السعر المقفل المتفق عليه:" else "السعر المستهدف:",
                        fontSize = 10.sp,
                        color = Color(0xFF64748B)
                    )
                    Text(
                        text = "${order.agreedPriceAed ?: order.merchantTargetPriceAed} د.إ",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = if (order.agreedPriceAed != null) WaselEmerald else WaselNavy
                    )
                }

                // CTA Button depending on status
                if (order.status == OrderStatus.WAITING_FOR_BIDS) {
                    Button(
                        onClick = onClick,
                        colors = ButtonDefaults.buttonColors(containerColor = WaselNavy),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Gavel,
                                contentDescription = null,
                                tint = WaselGold,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "العروض (${order.bids.size})",
                                color = Color.White,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                } else {
                    Button(
                        onClick = onClick,
                        colors = ButtonDefaults.buttonColors(containerColor = WaselEmerald),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.ArrowForward,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "تتبع الشحنة والتسليم",
                                color = Color.White,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun EmptyOrdersPlaceholder(onCreateClick: () -> Unit) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Color.White),
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 24.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(
                imageVector = Icons.Default.Gavel,
                contentDescription = null,
                tint = WaselGold,
                modifier = Modifier.size(48.dp)
            )
            Spacer(modifier = Modifier.height(12.dp))
            Text(
                text = "لا توجد طلبيات مطابقة للفلتر المختار",
                fontWeight = FontWeight.Bold,
                color = WaselNavy,
                fontSize = 15.sp
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = "قم بإنشاء طلبية توصيل جديدة واستقبل عروض أسعار السائقين فوراً.",
                color = Color(0xFF64748B),
                fontSize = 12.sp
            )
            Spacer(modifier = Modifier.height(16.dp))
            Button(
                onClick = onCreateClick,
                colors = ButtonDefaults.buttonColors(containerColor = WaselGold),
                shape = RoundedCornerShape(8.dp)
            ) {
                Text("إنشاء طلبية الآن", color = WaselNavy, fontWeight = FontWeight.Bold)
            }
        }
    }
}
