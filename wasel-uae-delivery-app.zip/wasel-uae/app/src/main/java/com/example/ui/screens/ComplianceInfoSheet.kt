package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AcUnit
import androidx.compose.material.icons.filled.Balance
import androidx.compose.material.icons.filled.Gavel
import androidx.compose.material.icons.filled.LocalShipping
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Pets
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Thermostat
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.WaselEmerald
import com.example.ui.theme.WaselGold
import com.example.ui.theme.WaselNavy

/**
 * دليل الاشتراطات والأنظمة والقوانين الإماراتية المعتمدة في التطبيق.
 * يعرض معلومات عن:
 * - منصة أساطيل (Asateel) وتصاريح النقل التجاري في أبوظبي.
 * - نظام درب (Darb) في أبوظبي وسالك (Salik) في دبي.
 * - قانون حظر العمل وقت الظهيرة الصيفي.
 * - اشتراطات وزارة التغير المناخي والبيئة لنقل الحيوانات.
 * - بروتوكولات الشوكولاتة والتمور والعطور الحرارية.
 * - رمز التحقق PIN لضمان التسليم الصحيح.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ComplianceInfoSheet(
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = Color.White,
        modifier = modifier.testTag("sheet_compliance_info")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 18.dp, vertical = 8.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(WaselNavy.copy(alpha = 0.1f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Shield,
                        contentDescription = null,
                        tint = WaselNavy,
                        modifier = Modifier.size(22.dp)
                    )
                }
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text(
                        text = "دليل الاشتراطات والأنظمة الإماراتية",
                        fontWeight = FontWeight.Bold,
                        color = WaselNavy,
                        fontSize = 16.sp
                    )
                    Text(
                        text = "نبذة موثقة عن الأطر القانونية والتشغيلية المعتمدة في تطبيق واصل الإمارات",
                        fontSize = 11.sp,
                        color = Color(0xFF64748B)
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // 1. منصة أساطيل
            ComplianceCard(
                icon = Icons.Default.Verified,
                title = "منصة أساطيل (Asateel) — مركز النقل المتكامل بأبوظبي",
                body = "تخضع جميع المركبات التجارية الخفيفة والثقيلة في أبوظبي للتسجيل في منصة أساطيل التابعة لـ(ITC). يجب أن يحمل كل سائق معتمد في التطبيق تصريح سائق (Driver Permit) مرتبطاً بالملف التجاري للشركة، وأن يكون قد أتمَّ البرامج التدريبية المعتمدة. التطبيق يعرض شارة (معتمد أساطيل/RTA) لكل كابتن متجاوز مع التحقق.",
                accentColor = WaselEmerald
            )

            // 2. القانون الاتحادي
            ComplianceCard(
                icon = Icons.Default.Balance,
                title = "القانون الاتحادي رقم 9 لسنة 2011 — النقل البري",
                body = "ينظّم القانون الاتحادي النقل التجاري ونقل البضائع على مستوى الدولة لضمان أمن وسلامة الشحنات والأفراد. يلتزم التطبيق بمتطلبات الترخيص والإذن بالممارسة لكافة السائقين المسجّلين، ولا يقبل عروض إلا من سائقين موثّقين.",
                accentColor = WaselNavy
            )

            // 3. سالك ودرب
            ComplianceCard(
                icon = Icons.Default.Speed,
                title = "نظاما التعرفة المرورية: سالك (دبي) ودرب (أبوظبي)",
                body = "يعتمد نظام سالك في دبي التسعير المتغير: 6 دراهم في أوقات الذروة و4 دراهم في الأوقات العادية، مع نافذة مجانية ليلية (1:00–6:00). أما نظام درب في أبوظبي فيستخدم تقنية ANPR دون ملصقات، و4 دراهم للعبور. يحسب التطبيق هذه الرسوم آلياً ويمنح السائق مرونة دمجها في عرضه التنافسي اللحظي.",
                accentColor = WaselGold
            )

            // 4. حظر الظهيرة
            ComplianceCard(
                icon = Icons.Default.Thermostat,
                title = "قانون حظر العمل وقت الظهيرة الصيفي (12:30–3:00)",
                body = "يلتزم التطبيق بقانون وزارة الموارد البشرية الإماراتي بتعليق استلام طلبات المنتجات الحساسة للحرارة (شوكولاتة، تمور، عطور) على الدراجات النارية في فترة الظهيرة الصيفية. يُوجَّه الطلب تلقائياً إلى المركبات المكيفة أو الفانات المبردة في هذه النافذة حمايةً للجودة.",
                accentColor = Color(0xFFF97316)
            )

            // 5. الحيوانات الأليفة
            ComplianceCard(
                icon = Icons.Default.Pets,
                title = "وزارة التغير المناخي والبيئة (MOCCAE) — نقل الحيوانات",
                body = "تشترط الوزارة جوازاً بيطرياً يثبت تحصين الحيوان ضد داء الكلب والفيروس الصغير، مع شريحة إلكترونية (ISO 15-digit Microchip) ومستندات استيراد سارية. يمنع التطبيق منعاً باتاً نقل الطيور والحيوانات الأليفة على الدراجات النارية، ويقبل فقط المركبات المكيفة المجهزة لتثبيت الأقفاص بحزام الأمان.",
                accentColor = Color(0xFF0F766E)
            )

            // 6. الشوكولاتة والتمور
            ComplianceCard(
                icon = Icons.Default.AcUnit,
                title = "النقل الحراري للشوكولاتة والتمور والعطور",
                body = "في صيف يتجاوز 45°C، يتعرض التوصيل بالدراجات النارية لخطر ذوبان وتزهير الشوكولاتة (Sugar Bloom). يطلب التطبيق صندوق توصيل معزول حرارياً مصنوع من ألياف زجاجية مقواة (FRP) كحد أدنى للدراجات، ويفضّل دائماً الفانات المبردة بدرجة 16–18°C للشحنات الفاخرة.",
                accentColor = Color(0xFF0284C7)
            )

            // 7. PIN التحقق
            ComplianceCard(
                icon = Icons.Default.Lock,
                title = "رمز التحقق الرباعي PIN عند التسليم",
                body = "يصدر التطبيق رمز PIN مكوّن من 4 أرقام لكل طلبية حساسة (هدايا، عطور، شحنات قيّمة). يُرسل الرمز للمستلم فقط عبر الرسائل القصيرة، ويُطلب من الكابتن إدخاله عند باب الوجهة لإتمام التسليم وتحرير المستحقات، مما يضمن استلام الشخص المعني شخصياً.",
                accentColor = Color(0xFF6D28D9)
            )

            // 8. السائق المستقل
            ComplianceCard(
                icon = Icons.Default.Gavel,
                title = "مزايدة عكسية نزيهة ضد (لعنة الفائز)",
                body = "يحسب التطبيق سعراً أدنى ديناميكياً لكل طلبية (Distance × Per-Km Rate + Tolls + Category Surcharge) لا يُقبل أي عرض دونه. هذا يمنع تسابق السائقين نحو الهبوط المدمّر للأسعار (Winner's Curse) ويضمن عدالة المزايدة وتنافسيتها الصحية بين الكباتن المعتمدين.",
                accentColor = WaselNavy
            )

            // 9. رخصة تاجر أبوظبي
            ComplianceCard(
                icon = Icons.Default.Public,
                title = "رخصة تاجر أبوظبي (Tajer Abu Dhabi)",
                body = "تتيح دائرة التنمية الاقتصادية بأبوظبي رخصة (تاجر أبوظبي) التي تعفي المنشأة من شرط استئجار مقر مادي لمدة 3 سنوات. يمكن استصدارها عبر منصة (تم - TAMM) بالهوية الرقمية (UAE Pass)، وهي مدخل低成本 مثالي لتأسيس كيان التوصيل بشكل افتراضي بالكامل.",
                accentColor = WaselGold
            )

            // 10. تكامل Fintech
            ComplianceCard(
                icon = Icons.Default.LocalShipping,
                title = "تكامل التقنية المالية (Pyypl / Pluto) — المشتريات بالنيابة",
                body = "لعمليات الشراء بالنيابة (Concierge) كالهدايا والعطور، يصدر التطبيق بطاقة ائتمان مؤسسية افتراضية ذات استعمال واحد تخصّص حصراً بقيمة الفاتورة المتوقعة. هذا يحمي أموال السائق من الاستنزاف ويمكّن التاجر من سداد القيمة المباشرة عند التسليم.",
                accentColor = Color(0xFF0F766E)
            )

            Spacer(modifier = Modifier.height(14.dp))

            Button(
                onClick = onDismiss,
                colors = ButtonDefaults.buttonColors(containerColor = WaselNavy),
                shape = RoundedCornerShape(10.dp),
                contentPadding = PaddingValues(vertical = 12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = "فهمت الاشتراطات والأنظمة",
                    color = Color.White,
                    fontWeight = FontWeight.Bold
                )
            }
            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}

@Composable
private fun ComplianceCard(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    body: String,
    accentColor: Color
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Color(0xFFF8FAFC)),
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 5.dp)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(30.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(accentColor.copy(alpha = 0.12f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = accentColor,
                        modifier = Modifier.size(18.dp)
                    )
                }
                Spacer(modifier = Modifier.width(10.dp))
                Text(
                    text = title,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF0F172A),
                    fontSize = 12.sp
                )
            }
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = body,
                fontSize = 11.sp,
                color = Color(0xFF475569),
                lineHeight = 17.sp
            )
        }
    }
}
