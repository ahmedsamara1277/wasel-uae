package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// UAE Luxury & Express Palette
val WaselNavy = Color(0xFF0B1B36)
val WaselNavyLight = Color(0xFF1E3A68)
val WaselGold = Color(0xFFF59E0B)
val WaselGoldLight = Color(0xFFFDE68A)
val WaselEmerald = Color(0xFF10B981)
val WaselEmeraldDark = Color(0xFF047857)

val DarkBackground = Color(0xFF081220)
val DarkSurface = Color(0xFF0F2042)
val DarkSurfaceVariant = Color(0xFF1B2F55)
val LightBackground = Color(0xFFF8FAFC)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFF1F5F9)

val TextPrimaryLight = Color(0xFF0F172A)
val TextSecondaryLight = Color(0xFF64748B)
val TextPrimaryDark = Color(0xFFF8FAFC)
val TextSecondaryDark = Color(0xFF94A3B8)

val ErrorRed = Color(0xFFEF4444)
val WarningOrange = Color(0xFFF97316)
val InfoBlue = Color(0xFF0284C7)
