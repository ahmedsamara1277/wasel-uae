package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.AcUnit
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Gavel
import androidx.compose.material.icons.filled.LocalShipping
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Pets
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Thermostat
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.DeliveryOrder
import com.example.model.OrderStatus
import com.example.model.UserRole
import com.example.ui.components.AsateelBadge
import com.example.ui.components.BidCard
import com.example.ui.components.ChatThread
import com.example.ui.components.ClimateBadge
import com.example.ui.components.DriverInfoBlock
import com.example.ui.components.OrderStatusStepper
import com.example.ui.components.PinVerificationDialog
import com.example.ui.theme.WaselEmerald
import com.example.ui.theme.WaselGold
import com.example.ui.theme.WaselNavy

/**
 * شاشة تفاصيل الطلب الكاملة:
 * - تعرض معلومات الشحنة، الطريق، السعر، الرسوم، ورمز PIN.
 * - تعرض شريط مراحل التنفيذ (Status Stepper).
 * - للتاجر: قائمة العروض التنافسية مع زر قبول كل عرض.
 * - للسائق: زر تقديم عرض سعر تنافسي على الطلب المفتوح.
 * - تعرض محادثة ثنائية بين التاجر والكابتن مع إمكانية إرسال رسائل جديدة.
 * - تعرض زر إدخال رمز التحقق عند وصول مرحلة التسليم.
 */
@Composable
fun OrderDetailScreen(
    order: DeliveryOrder,
    currentRole: UserRole,
    onBack: () -> Unit,
    onAcceptBid: (String) -> Unit,
    onAdvanceStatus: () -> Unit,
    onVerifyPin: (String) -> Boolean,
    onSendChat: (String) -> Unit,
    onPlaceBidClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    var showPinDialog by rememberSaveable { mutableStateOf(false) }
    var chatInput by rememberSaveable { mutableStateOf("") }

    val isMerchant = currentRole == UserRole.MERCHANT
    val isWaitingForBids = order.status == OrderStatus.WAITING_FOR_BIDS
    val isAccepted = order.status.stepIndex >= OrderStatus.BID_ACCEPTED.stepIndex &&
            order.status != OrderStatus.CANCELLED
    val canVerifyPin = order.status == OrderStatus.IN_TRANSIT
    val canAdvance = isAccepted && order.status != OrderStatus.DELIVERED &&
            order.status != OrderStatus.IN_TRANSIT

    Box(modifier = modifier.fillMaxSize()) {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 14.dp, end = 14.dp, top = 8.dp, bottom = 100.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // رأس الصفحة: زر الرجوع + رقم التتبع
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = onBack, modifier = Modifier.testTag("btn_back")) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "رجوع",
                            tint = WaselNavy
                        )
                    }
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "طلبية ${order.trackingCode}",
                            fontWeight = FontWeight.Bold,
                            color = WaselNavy,
                            fontSize = 16.sp
                        )
                        Text(
                            text = order.category.titleAr,
                            fontSize = 12.sp,
                            color = Color(0xFF64748B)
                        )
                    }
                    Surface(
                        color = when (order.status) {
                            OrderStatus.WAITING_FOR_BIDS -> WaselGold.copy(alpha = 0.18f)
                            OrderStatus.DELIVERED -> WaselEmerald.copy(alpha = 0.18f)
                            OrderStatus.CANCELLED -> Color(0xFFFEE2E2)
                            else -> WaselNavy.copy(alpha = 0.1f)
                        },
                        shape = RoundedCornerShape(20.dp)
                    ) {
                        Text(
                            text = order.status.titleAr,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = when (order.status) {
                                OrderStatus.WAITING_FOR_BIDS -> Color(0xFFB45309)
                                OrderStatus.DELIVERED -> Color(0xFF065F46)
                                OrderStatus.CANCELLED -> Color(0xFFB91C1C)
                                else -> WaselNavy
                            },
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                        )
                    }
                }
            }

            // بطاقة العنوان والوصف
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    shape = RoundedCornerShape(14.dp),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(
                            text = order.title,
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            color = Color(0xFF0F172A)
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = order.description,
                            fontSize = 12.sp,
                            color = Color(0xFF475569)
                        )
                        Spacer(modifier = Modifier.height(12.dp))

                        // الطريق: من → إلى
                        RouteCard(order = order)

                        Spacer(modifier = Modifier.height(10.dp))

                        // شارات المتطلبات الخاصة
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            ClimateBadge(isCooling = order.category.requiresAC)
                            if (order.category.requiresLiveAnimalCare) {
                                Surface(
                                    color = Color(0xFFCCFBF1),
                                    shape = RoundedCornerShape(4.dp)
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Pets,
                                            contentDescription = null,
                                            tint = Color(0xFF0F766E),
                                            modifier = Modifier.size(12.dp)
                                        )
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(
                                            "رفق بالحيوان",
                                            color = Color(0xFF0F766E),
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.SemiBold
                                        )
                                    }
                                }
                            }
                            if (order.category.requiresSecurePin) {
                                Surface(
                                    color = Color(0xFFEDE9FE),
                                    shape = RoundedCornerShape(4.dp)
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Lock,
                                            contentDescription = null,
                                            tint = Color(0xFF6D28D9),
                                            modifier = Modifier.size(12.dp)
                                        )
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(
                                            "تسليم برمز PIN",
                                            color = Color(0xFF6D28D9),
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.SemiBold
                                        )
                                    }
                                }
                            }
                            if (order.is247Express) {
                                Surface(
                                    color = Color(0xFFFEF3C7),
                                    shape = RoundedCornerShape(4.dp)
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Speed,
                                            contentDescription = null,
                                            tint = Color(0xFFB45309),
                                            modifier = Modifier.size(12.dp)
                                        )
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(
                                            "24/7 فوري",
                                            color = Color(0xFFB45309),
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.SemiBold
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // بطاقة السعر ورسوم التعرفة
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = WaselNavy),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text(
                                    text = if (order.agreedPriceAed != null)
                                        "السعر المقفل المتفق عليه"
                                    else "السعر المستهدف للتاجر",
                                    color = Color(0xFFCBD5E1),
                                    fontSize = 11.sp
                                )
                                Text(
                                    text = "${order.agreedPriceAed?.toInt() ?: order.merchantTargetPriceAed.toInt()} د.إ",
                                    color = Color.White,
                                    fontSize = 22.sp,
                                    fontWeight = FontWeight.ExtraBold
                                )
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text(
                                    text = "السعر الأدنى الديناميكي",
                                    color = Color(0xFFCBD5E1),
                                    fontSize = 11.sp
                                )
                                Text(
                                    text = "${order.dynamicFloorPriceAed.toInt()} د.إ",
                                    color = WaselGold,
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(10.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            PriceChip(
                                label = "المسافة",
                                value = "${order.distanceKm} كم"
                            )
                            PriceChip(
                                label = "رسوم سالك/درب",
                                value = "${order.estimatedTollsAed.toInt()} د.إ"
                            )
                            PriceChip(
                                label = "رمز PIN",
                                value = if (isMerchant) order.deliveryPin else "••••"
                            )
                        }
                    }
                }
            }

            // شريط مراحل التنفيذ
            if (isAccepted || order.status == OrderStatus.DELIVERED) {
                item {
                    OrderStatusStepper(currentStatus = order.status)
                }
            }

            // معلومات الكابتن المختار + أزرار التحكم بعد القبول
            if (order.selectedDriver != null) {
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        shape = RoundedCornerShape(14.dp),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                        modifier = Modifier.testTag("card_selected_driver")
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Text(
                                text = "الكابتن المعتمد للرحلة",
                                fontWeight = FontWeight.Bold,
                                color = WaselNavy,
                                fontSize = 13.sp
                            )
                            Spacer(modifier = Modifier.height(10.dp))
                            DriverInfoBlock(
                                driver = order.selectedDriver,
                                showContactAction = true,
                                onCallDriver = { /* سيادة الواجهة تستدعي طلب الاتصال لاحقاً */ }
                            )
                            Spacer(modifier = Modifier.height(10.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                AsateelBadge()
                                if (order.selectedDriver.vehicleType.isClimateControlled) {
                                    Surface(
                                        color = Color(0xFF0284C7).copy(alpha = 0.12f),
                                        shape = RoundedCornerShape(4.dp)
                                    ) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.AcUnit,
                                                contentDescription = null,
                                                tint = Color(0xFF0284C7),
                                                modifier = Modifier.size(12.dp)
                                            )
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text(
                                                "مركبة مكيفة",
                                                color = Color(0xFF0284C7),
                                                fontSize = 10.sp,
                                                fontWeight = FontWeight.Bold
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                // أزرار التحكم بالرحلة (يستخدمها الكابتن أو التاجر للمتابعة)
                if (canAdvance) {
                    item {
                        Button(
                            onClick = onAdvanceStatus,
                            colors = ButtonDefaults.buttonColors(containerColor = WaselNavy),
                            shape = RoundedCornerShape(10.dp),
                            contentPadding = PaddingValues(vertical = 12.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("btn_advance_status")
                        ) {
                            Icon(
                                imageVector = Icons.Default.LocalShipping,
                                contentDescription = null,
                                tint = WaselGold,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "تحديث حالة الرحلة للمتابعة",
                                color = Color.White,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }

                // زر التحقق من PIN عند مرحلة "في الطريق"
                if (canVerifyPin) {
                    item {
                        Button(
                            onClick = { showPinDialog = true },
                            colors = ButtonDefaults.buttonColors(containerColor = WaselEmerald),
                            shape = RoundedCornerShape(10.dp),
                            contentPadding = PaddingValues(vertical = 14.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("btn_open_pin_dialog")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Verified,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "تأكيد التسليم برمز التحقق السري",
                                color = Color.White,
                                fontWeight = FontWeight.ExtraBold
                            )
                        }
                    }
                }
            }

            // قسم العروض التنافسية - فقط للتاجر في مرحلة بانتظار العروض
            if (isMerchant && order.status == OrderStatus.WAITING_FOR_BIDS) {
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "العروض التنافسية المقدّمة",
                            fontWeight = FontWeight.Bold,
                            color = WaselNavy,
                            fontSize = 14.sp
                        )
                        Surface(
                            color = WaselGold.copy(alpha = 0.18f),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text(
                                text = "${order.bids.size} عرض",
                                color = Color(0xFFB45309),
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }
                }

                if (order.bids.isEmpty()) {
                    item {
                        Surface(
                            color = Color(0xFFFEF3C7),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(14.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Thermostat,
                                    contentDescription = null,
                                    tint = Color(0xFFB45309),
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "بانتظار وصول أول عرض من السائقين المؤهلين. يتم بث الطلبية آلياً إلى المناديب المعتمدين ضمن النطاق الجغرافي.",
                                    fontSize = 12.sp,
                                    color = Color(0xFF451A03)
                                )
                            }
                        }
                    }
                } else {
                    // ترتيب العروض تصاعدياً حسب السعر (الأفضل أولاً)
                    val sortedBids = order.bids.sortedBy { it.amountAed }
                    items(sortedBids, key = { it.id }) { bid ->
                        BidCard(
                            bid = bid,
                            isWinning = bid.id == sortedBids.first().id,
                            canAccept = true,
                            onAccept = { onAcceptBid(bid.id) }
                        )
                    }
                }
            }

            // زر تقديم عرض للسائق على الطلب المفتوح
            if (!isMerchant && order.status == OrderStatus.WAITING_FOR_BIDS) {
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color(0xFFEFF6FF)),
                        shape = RoundedCornerShape(14.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, WaselGold)
                    ) {
                        Column(
                            modifier = Modifier.padding(14.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                text = "هذه الطلبية متاحة للمزايدة الآن",
                                fontWeight = FontWeight.Bold,
                                color = WaselNavy,
                                fontSize = 13.sp
                            )
                            Text(
                                text = "قدّم عرضك التنافسي. السعر المستهدف للتاجر ${order.merchantTargetPriceAed.toInt()} د.إ. أفضل عرض يُقفل فور قبوله.",
                                fontSize = 11.sp,
                                color = Color(0xFF475569),
                                modifier = Modifier.padding(top = 4.dp)
                            )
                            Spacer(modifier = Modifier.height(10.dp))
                            Button(
                                onClick = onPlaceBidClick,
                                colors = ButtonDefaults.buttonColors(containerColor = WaselGold),
                                shape = RoundedCornerShape(10.dp),
                                contentPadding = PaddingValues(vertical = 12.dp, horizontal = 24.dp),
                                modifier = Modifier.testTag("btn_driver_place_bid")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Gavel,
                                    contentDescription = null,
                                    tint = WaselNavy,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "تقديم عرض سعر تنافسي",
                                    color = WaselNavy,
                                    fontWeight = FontWeight.ExtraBold
                                )
                            }
                        }
                    }
                }
            }

            // قسم المحادثة
            item {
                Text(
                    text = "محادثة الرحلة",
                    fontWeight = FontWeight.Bold,
                    color = WaselNavy,
                    fontSize = 14.sp,
                    modifier = Modifier.padding(top = 4.dp, bottom = 4.dp)
                )
            }
            // عرض آخر 30 رسالة فقط لأداء أفضل
            val recentMessages = order.chatMessages.takeLast(30)
            item {
                Surface(
                    color = Color(0xFFF8FAFC),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(220.dp)
                ) {
                    ChatThread(
                        messages = recentMessages,
                        modifier = Modifier.padding(8.dp)
                    )
                }
            }
        }

        // شريط إدخال رسالة جديدة (أسفل الشاشة)
        Surface(
            color = Color.White,
            shadowElevation = 8.dp,
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = chatInput,
                    onValueChange = { chatInput = it.take(280) },
                    placeholder = { Text("اكتب رسالتك للطرف الآخر...", fontSize = 12.sp) },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("field_chat_input"),
                    singleLine = true,
                    shape = RoundedCornerShape(20.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                IconButton(
                    onClick = {
                        if (chatInput.isNotBlank()) {
                            onSendChat(chatInput.trim())
                            chatInput = ""
                        }
                    },
                    modifier = Modifier
                        .clip(RoundedCornerShape(20.dp))
                        .background(WaselNavy)
                        .size(44.dp)
                        .testTag("btn_send_chat")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.Send,
                        contentDescription = "إرسال",
                        tint = Color.White
                    )
                }
            }
        }
    }

    if (showPinDialog) {
        PinVerificationDialog(
            expectedHint = "الرمز الصحيح مُرسل للمستلم فقط ولا يطلع عليه الكابتن",
            onConfirm = { pin ->
                val ok = onVerifyPin(pin)
                if (ok) showPinDialog = false
                ok
            },
            onDismiss = { showPinDialog = false }
        )
    }
}

@Composable
private fun RouteCard(order: DeliveryOrder) {
    Surface(
        color = Color(0xFFF8FAFC),
        shape = RoundedCornerShape(10.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .clip(RoundedCornerShape(50))
                        .background(WaselGold)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Icon(
                    imageVector = Icons.Default.LocationOn,
                    contentDescription = null,
                    tint = Color(0xFFB45309),
                    modifier = Modifier.size(14.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = "من: ${order.pickupEmirate.nameAr} — ${order.pickupLocation}",
                    fontSize = 11.sp,
                    color = Color(0xFF334155),
                    fontWeight = FontWeight.Medium
                )
            }
            Spacer(modifier = Modifier.height(8.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .clip(RoundedCornerShape(50))
                        .background(WaselEmerald)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Icon(
                    imageVector = Icons.Default.LocationOn,
                    contentDescription = null,
                    tint = Color(0xFF047857),
                    modifier = Modifier.size(14.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = "إلى: ${order.dropoffEmirate.nameAr} — ${order.dropoffLocation}",
                    fontSize = 11.sp,
                    color = Color(0xFF334155),
                    fontWeight = FontWeight.Medium
                )
            }
        }
    }
}

@Composable
private fun PriceChip(label: String, value: String) {
    Column {
        Text(
            text = label,
            color = Color(0xFFCBD5E1),
            fontSize = 10.sp
        )
        Text(
            text = value,
            color = Color.White,
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold
        )
    }
}
