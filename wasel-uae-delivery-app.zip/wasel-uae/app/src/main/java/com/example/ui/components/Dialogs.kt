package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Gavel
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Snackbar
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.WaselEmerald
import com.example.ui.theme.WaselGold
import com.example.ui.theme.WaselNavy

/**
 * نافذة تحقق رمز PIN الرباعي عند التسليم النهائي.
 * يضمن أن المستلم الصحيح هو من استلم الشحنة قبل تحرير مستحقات الكابتن.
 */
@Composable
fun PinVerificationDialog(
    expectedHint: String,
    onConfirm: (String) -> Boolean,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier
) {
    var pin by rememberSaveable { mutableStateOf("") }
    var error by rememberSaveable { mutableStateOf<String?>(null) }

    AlertDialog(
        modifier = modifier.testTag("dialog_pin_verify"),
        onDismissRequest = onDismiss,
        icon = {
            Box(
                modifier = Modifier
                    .size(48.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(WaselEmerald.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Lock,
                    contentDescription = null,
                    tint = WaselEmerald,
                    modifier = Modifier.size(28.dp)
                )
            }
        },
        title = {
            Text(
                text = "تحقق رمز التسليم السري",
                fontWeight = FontWeight.Bold,
                color = WaselNavy
            )
        },
        text = {
            Column {
                Text(
                    text = "أدخل رمز الـ4 أرقام الذي استلمه المستلم عبر الرسالة القصيرة لتأكيد التسليم وتحرير مستحقات الكابتن.",
                    fontSize = 12.sp,
                    color = Color(0xFF475569)
                )
                Spacer(modifier = Modifier.height(8.dp))
                if (expectedHint.isNotBlank()) {
                    Text(
                        text = "تلميح الأمان: $expectedHint",
                        fontSize = 10.sp,
                        color = Color(0xFF94A3B8)
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                }
                OutlinedTextField(
                    value = pin,
                    onValueChange = { value ->
                        if (value.length <= 4 && value.all { it.isDigit() }) {
                            pin = value
                            error = null
                        }
                    },
                    label = { Text("رمز PIN (4 أرقام)") },
                    singleLine = true,
                    isError = error != null,
                    supportingText = {
                        if (error != null) {
                            Text(
                                text = error!!,
                                color = MaterialTheme.colorScheme.error,
                                fontSize = 11.sp
                            )
                        }
                    },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("field_pin_input")
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (pin.length != 4) {
                        error = "الرمز يجب أن يكون 4 أرقام"
                        return@Button
                    }
                    val success = onConfirm(pin)
                    if (!success) {
                        error = "الرمز غير صحيح، يرجى المراجعة مع المستلم"
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = WaselEmerald),
                modifier = Modifier.testTag("btn_pin_confirm")
            ) {
                Text("تأكيد الرمز وإكمال التسليم", color = Color.White, fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("إلغاء", color = Color(0xFF64748B))
            }
        }
    )
}

/**
 * نافذة سفلية لتمكين السائق من تقديم عرض سعر تنافسي على طلبية مفتوحة.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BidPlacementSheet(
    suggestedFloorPrice: Double,
    targetPrice: Double,
    onPlaceBid: (amountAed: Double, etaMinutes: Int, noteAr: String) -> Unit,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    var amountText by rememberSaveable { mutableStateOf(targetPrice.toInt().toString()) }
    var etaText by rememberSaveable { mutableStateOf("15") }
    var noteText by rememberSaveable { mutableStateOf("") }
    var amountError by rememberSaveable { mutableStateOf<String?>(null) }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = Color.White,
        modifier = modifier.testTag("sheet_place_bid")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 8.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(WaselGold.copy(alpha = 0.18f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Gavel,
                        contentDescription = null,
                        tint = WaselGold,
                        modifier = Modifier.size(20.dp)
                    )
                }
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text(
                        text = "تقديم عرض تنافسي",
                        fontWeight = FontWeight.Bold,
                        color = WaselNavy,
                        fontSize = 16.sp
                    )
                    Text(
                        text = "حدد سعرك ومدة وصولك المقدّرة. كلما كان عرضك أقرب لاحتياج التاجر زادت فرصة قبوله.",
                        fontSize = 11.sp,
                        color = Color(0xFF64748B)
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // السعر الأدنى الديناميكي المقترح
            Surface(
                color = Color(0xFFF1F5F9),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text(
                            text = "السعر الأدنى الديناميكي",
                            fontSize = 11.sp,
                            color = Color(0xFF64748B)
                        )
                        Text(
                            text = "${suggestedFloorPrice.toInt()} د.إ",
                            fontWeight = FontWeight.Bold,
                            color = WaselNavy,
                            fontSize = 16.sp
                        )
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = "السعر المستهدف للتاجر",
                            fontSize = 11.sp,
                            color = Color(0xFF64748B)
                        )
                        Text(
                            text = "${targetPrice.toInt()} د.إ",
                            fontWeight = FontWeight.Bold,
                            color = WaselEmerald,
                            fontSize = 16.sp
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            OutlinedTextField(
                value = amountText,
                onValueChange = { value ->
                    if (value.all { it.isDigit() } || value.isEmpty()) {
                        amountText = value
                        amountError = null
                    }
                },
                label = { Text("عرض سعرك (درهم إماراتي)") },
                singleLine = true,
                isError = amountError != null,
                supportingText = {
                    if (amountError != null) {
                        Text(amountError!!, color = MaterialTheme.colorScheme.error, fontSize = 11.sp)
                    }
                },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("field_bid_amount")
            )

            Spacer(modifier = Modifier.height(10.dp))

            OutlinedTextField(
                value = etaText,
                onValueChange = { value ->
                    if (value.all { it.isDigit() } || value.isEmpty()) etaText = value
                },
                label = { Text("مدة الوصول للاستلام (بالدقائق)") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("field_bid_eta")
            )

            Spacer(modifier = Modifier.height(10.dp))

            OutlinedTextField(
                value = noteText,
                onValueChange = { noteText = it.take(160) },
                label = { Text("ملاحظة للتاجر (اختياري)") },
                supportingText = { Text("مثال: مركبة مكيفة، متاح فوراً، علامة مميزة", fontSize = 10.sp) },
                minLines = 2,
                maxLines = 3,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("field_bid_note")
            )

            Spacer(modifier = Modifier.height(18.dp))

            Button(
                onClick = {
                    val amount = amountText.toDoubleOrNull()
                    val eta = etaText.toIntOrNull()
                    if (amount == null || amount < suggestedFloorPrice) {
                        amountError = "يجب ألا يقل عرضك عن السعر الأدنى الديناميكي"
                        return@Button
                    }
                    if (eta == null || eta <= 0) {
                        amountError = "أدخل مدة وصول صحيحة"
                        return@Button
                    }
                    onPlaceBid(amount, eta, noteText)
                },
                colors = ButtonDefaults.buttonColors(containerColor = WaselGold),
                shape = RoundedCornerShape(10.dp),
                contentPadding = PaddingValues(vertical = 14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("btn_submit_bid")
            ) {
                Text(
                    text = "إرسال العرض للتاجر",
                    color = WaselNavy,
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 14.sp,
                    textAlign = TextAlign.Center
                )
            }
            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}

@Composable
fun WaselActionSnackbar(
    hostState: SnackbarHostState,
    modifier: Modifier = Modifier
) {
    SnackbarHost(hostState = hostState, modifier = modifier) { data ->
        Snackbar(
            snackbarData = data,
            containerColor = WaselNavy,
            contentColor = Color.White,
            actionColor = WaselGold
        )
    }
}
