package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AcUnit
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Pets
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.Emirate
import com.example.model.OrderCategory
import com.example.ui.theme.WaselEmerald
import com.example.ui.theme.WaselGold
import com.example.ui.theme.WaselNavy

/**
 * نافذة إنشاء طلبية جديدة مع معاينة حيّة للسعر الأدنى الديناميكي،
 * المسافة المقدّرة، ورسوم التعرفة المرورية (سالك/درب).
 * يستخدمها التاجر لنشر شحنته في سوق المزايدة اللحظي.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CreateOrderSheet(
    onCalculateFloor: (Emirate, Emirate, OrderCategory) -> Double,
    onCalculateDistance: (Emirate, Emirate) -> Int,
    onCalculateTolls: (Emirate, Emirate) -> Double,
    onCreateOrder: (title: String, description: String, category: OrderCategory,
                    pickupEmirate: Emirate, pickupLocation: String,
                    dropoffEmirate: Emirate, dropoffLocation: String,
                    targetPrice: Double, is247Express: Boolean) -> Unit,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    // حقول النموذج
    var title by rememberSaveable { mutableStateOf("") }
    var description by rememberSaveable { mutableStateOf("") }
    var pickupLocation by rememberSaveable { mutableStateOf("") }
    var dropoffLocation by rememberSaveable { mutableStateOf("") }
    var targetPriceText by rememberSaveable { mutableStateOf("") }
    var is247Express by rememberSaveable { mutableStateOf(true) }
    var titleError by rememberSaveable { mutableStateOf<String?>(null) }
    var locationError by rememberSaveable { mutableStateOf<String?>(null) }
    var priceError by rememberSaveable { mutableStateOf<String?>(null) }

    // اختيارات منفصلة (non-savable enums)
    var selectedCategory by remember { mutableStateOf(OrderCategory.GIFTS_PERFUMES) }
    var pickupEmirate by remember { mutableStateOf(Emirate.DUBAI) }
    var dropoffEmirate by remember { mutableStateOf(Emirate.ABU_DHABI) }

    // الحسابات الحية
    val distanceKm = onCalculateDistance(pickupEmirate, dropoffEmirate)
    val tollsAed = onCalculateTolls(pickupEmirate, dropoffEmirate)
    val floorPrice = onCalculateFloor(pickupEmirate, dropoffEmirate, selectedCategory)
    val suggestedTarget = floorPrice + 15.0

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = Color.White,
        modifier = modifier.testTag("sheet_create_order")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 18.dp, vertical = 8.dp)
        ) {
            // رأس النموذج
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(WaselGold.copy(alpha = 0.18f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Add,
                        contentDescription = null,
                        tint = WaselGold,
                        modifier = Modifier.size(22.dp)
                    )
                }
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text(
                        text = "إنشاء طلبية توصيل جديدة",
                        fontWeight = FontWeight.Bold,
                        color = WaselNavy,
                        fontSize = 18.sp
                    )
                    Text(
                        text = "املأ الحقول، شاهد السعر الأدنى الديناميكي، وانشر شحنتك في سوق المزايدة فوراً.",
                        fontSize = 11.sp,
                        color = Color(0xFF64748B)
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // اختيار التصنيف
            Text(
                text = "تصنيف الشحنة",
                fontWeight = FontWeight.Bold,
                color = WaselNavy,
                fontSize = 13.sp
            )
            Spacer(modifier = Modifier.height(6.dp))
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OrderCategory.values().forEach { cat ->
                    FilterChip(
                        selected = selectedCategory == cat,
                        onClick = { selectedCategory = cat },
                        leadingIcon = {
                            Icon(
                                imageVector = cat.icon,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp)
                            )
                        },
                        label = { Text(cat.titleAr, fontSize = 11.sp) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = WaselNavy,
                            selectedLabelColor = Color.White
                        )
                    )
                }
            }

            Spacer(modifier = Modifier.height(6.dp))
            // وصف متطلبات التصنيف
            Surface(
                color = Color(0xFFF8FAFC),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(modifier = Modifier.padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = selectedCategory.descriptionAr,
                        fontSize = 11.sp,
                        color = Color(0xFF475569)
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // العنوان والوصف
            OutlinedTextField(
                value = title,
                onValueChange = { title = it.take(80); titleError = null },
                label = { Text("عنوان الطلبية") },
                singleLine = true,
                isError = titleError != null,
                supportingText = {
                    if (titleError != null) Text(titleError!!, color = MaterialTheme.colorScheme.error, fontSize = 11.sp)
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("field_order_title")
            )
            Spacer(modifier = Modifier.height(10.dp))
            OutlinedTextField(
                value = description,
                onValueChange = { description = it.take(280) },
                label = { Text("وصف الشحنة وتعليمات خاصة للكابتن") },
                minLines = 2,
                maxLines = 4,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("field_order_description")
            )

            Spacer(modifier = Modifier.height(14.dp))

            // إمارة الاستلام + موقعها
            Text(
                text = "إمارة الاستلام",
                fontWeight = FontWeight.Bold,
                color = WaselNavy,
                fontSize = 13.sp
            )
            Spacer(modifier = Modifier.height(6.dp))
            EmiratePickerRow(
                selected = pickupEmirate,
                onSelect = { pickupEmirate = it }
            )
            Spacer(modifier = Modifier.height(6.dp))
            OutlinedTextField(
                value = pickupLocation,
                onValueChange = { pickupLocation = it.take(120); locationError = null },
                label = { Text("عنوان الاستلام بالتفصيل") },
                singleLine = true,
                isError = locationError != null,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("field_pickup_location")
            )

            Spacer(modifier = Modifier.height(14.dp))

            // إمارة التسليم + موقعها
            Text(
                text = "إمارة التسليم",
                fontWeight = FontWeight.Bold,
                color = WaselNavy,
                fontSize = 13.sp
            )
            Spacer(modifier = Modifier.height(6.dp))
            EmiratePickerRow(
                selected = dropoffEmirate,
                onSelect = { dropoffEmirate = it }
            )
            Spacer(modifier = Modifier.height(6.dp))
            OutlinedTextField(
                value = dropoffLocation,
                onValueChange = { dropoffLocation = it.take(120); locationError = null },
                label = { Text("عنوان التسليم بالتفصيل") },
                singleLine = true,
                isError = locationError != null,
                supportingText = {
                    if (locationError != null) Text(locationError!!, color = MaterialTheme.colorScheme.error, fontSize = 11.sp)
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("field_dropoff_location")
            )

            Spacer(modifier = Modifier.height(14.dp))

            // بطاقة المعاينة المالية الحية
            Card(
                colors = CardDefaults.cardColors(containerColor = WaselNavy),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Calculate,
                            contentDescription = null,
                            tint = WaselGold,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "المعاينة المالية الديناميكية",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        PreviewColumn("المسافة المقدّرة", "${distanceKm} كم", Color.White)
                        PreviewColumn("رسوم التعرفة", "${tollsAed.toInt()} د.إ", Color.White)
                        PreviewColumn("السعر الأدنى", "${floorPrice.toInt()} د.إ", WaselGold)
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Surface(
                        color = Color(0xFF1E293B),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = "السعر المقترح للتاجر: ${suggestedTarget.toInt()} د.إ — يمكنك تعديله صعوداً أو نزولاً دون النزول عن السعر الأدنى.",
                            color = Color(0xFFE2E8F0),
                            fontSize = 11.sp,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // السعر المستهدف
            OutlinedTextField(
                value = targetPriceText,
                onValueChange = { value ->
                    if (value.all { it.isDigit() } || value.isEmpty()) {
                        targetPriceText = value
                        priceError = null
                    }
                },
                label = { Text("السعر المستهدف للتاجر (درهم)") },
                singleLine = true,
                isError = priceError != null,
                supportingText = {
                    if (priceError != null) {
                        Text(priceError!!, color = MaterialTheme.colorScheme.error, fontSize = 11.sp)
                    } else {
                        Text("أدخل السعر الذي ترغب بدفع العرض على أساسه", fontSize = 10.sp)
                    }
                },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("field_target_price")
            )

            Spacer(modifier = Modifier.height(14.dp))

            // شارات المتطلبات الخاصة بالتصنيف
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                if (selectedCategory.requiresAC) SpecialBadge("مركبة مكيفة", Color(0xFF0284C7), Icons.Default.AcUnit)
                if (selectedCategory.requiresColdStorage) SpecialBadge("تبريد مستمر", Color(0xFF0891B2), Icons.Default.AcUnit)
                if (selectedCategory.requiresLiveAnimalCare) SpecialBadge("رفق بالحيوان", Color(0xFF0F766E), Icons.Default.Pets)
                if (selectedCategory.requiresSecurePin) SpecialBadge("رمز PIN للتحقق", Color(0xFF6D28D9), Icons.Default.Lock)
                SpecialBadge("24/7 فوري", Color(0xFFB45309), Icons.Default.Speed)
            }

            Spacer(modifier = Modifier.height(20.dp))

            // زر النشر في سوق المزايدة
            Button(
                onClick = {
                    // التحقق من المدخلات
                    if (title.isBlank()) {
                        titleError = "أدخل عنواناً واضحاً للطلبية"
                        return@Button
                    }
                    if (pickupLocation.isBlank() || dropoffLocation.isBlank()) {
                        locationError = "أدخل عنواني الاستلام والتسليم"
                        return@Button
                    }
                    val target = targetPriceText.toDoubleOrNull()
                    if (target == null || target < floorPrice) {
                        priceError = "يجب ألا يقل السعر عن الحد الأدنى الديناميكي (${floorPrice.toInt()} د.إ)"
                        return@Button
                    }
                    onCreateOrder(
                        title.trim(),
                        description.trim().ifBlank { selectedCategory.descriptionAr },
                        selectedCategory,
                        pickupEmirate,
                        pickupLocation.trim(),
                        dropoffEmirate,
                        dropoffLocation.trim(),
                        target,
                        is247Express
                    )
                },
                colors = ButtonDefaults.buttonColors(containerColor = WaselGold),
                shape = RoundedCornerShape(10.dp),
                contentPadding = PaddingValues(vertical = 14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("btn_publish_order")
            ) {
                Icon(
                    imageVector = Icons.Default.Add,
                    contentDescription = null,
                    tint = WaselNavy,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "نشر الطلبية في سوق المزايدة اللحظي",
                    color = WaselNavy,
                    fontWeight = FontWeight.ExtraBold,
                    fontSize = 14.sp
                )
            }
            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}

@Composable
private fun EmiratePickerRow(selected: Emirate, onSelect: (Emirate) -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Emirate.values().forEach { em ->
            FilterChip(
                selected = selected == em,
                onClick = { onSelect(em) },
                label = { Text(em.nameAr, fontSize = 11.sp) },
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = WaselEmerald,
                    selectedLabelColor = Color.White
                )
            )
        }
    }
}

@Composable
private fun PreviewColumn(label: String, value: String, valueColor: Color) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            text = label,
            color = Color(0xFFCBD5E1),
            fontSize = 10.sp
        )
        Text(
            text = value,
            color = valueColor,
            fontWeight = FontWeight.Bold,
            fontSize = 14.sp
        )
    }
}

@Composable
private fun SpecialBadge(text: String, color: Color, icon: androidx.compose.ui.graphics.vector.ImageVector) {
    Surface(
        color = color.copy(alpha = 0.12f),
        shape = RoundedCornerShape(4.dp)
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = color,
                modifier = Modifier.size(12.dp)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
                text = text,
                color = color,
                fontSize = 10.sp,
                fontWeight = FontWeight.SemiBold
            )
        }
    }
}
