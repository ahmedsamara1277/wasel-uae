package com.example.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.WaselRepository
import com.example.model.DeliveryOrder
import com.example.model.DriverProfile
import com.example.model.Emirate
import com.example.model.OrderCategory
import com.example.model.OrderStatus
import com.example.model.UserRole
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class WaselUiState(
    val currentRole: UserRole = UserRole.MERCHANT,
    val orders: List<DeliveryOrder> = emptyList(),
    val filteredOrders: List<DeliveryOrder> = emptyList(),
    val selectedOrder: DeliveryOrder? = null,
    val selectedCategoryFilter: OrderCategory? = null,
    val selectedEmirateFilter: Emirate? = null,
    val currentDriver: DriverProfile,
    val showCreateOrderSheet: Boolean = false,
    val showComplianceSheet: Boolean = false,
    val showBidPlacementSheet: Boolean = false,
    val lastActionMessage: String? = null
)

class WaselViewModel(
    private val repository: WaselRepository = WaselRepository()
) : ViewModel() {

    private val _currentRole = MutableStateFlow(UserRole.MERCHANT)
    private val _selectedOrderId = MutableStateFlow<String?>(null)
    private val _selectedCategoryFilter = MutableStateFlow<OrderCategory?>(null)
    private val _selectedEmirateFilter = MutableStateFlow<Emirate?>(null)
    private val _showCreateOrderSheet = MutableStateFlow(false)
    private val _showComplianceSheet = MutableStateFlow(false)
    private val _showBidPlacementSheet = MutableStateFlow(false)
    private val _lastActionMessage = MutableStateFlow<String?>(null)

    // combine يدعم حتى 5 تدفقات مباشرة؛ نستخدم دمجاً متسلسلاً للوصول إلى 9 مصادر.
    val uiState: StateFlow<WaselUiState> = combine(
        repository.orders,
        _currentRole,
        _selectedOrderId,
        _selectedCategoryFilter,
        _selectedEmirateFilter
    ) { orders, role, selectedId, catFilter, emFilter ->
        WaselUiPartial(
            orders = orders,
            role = role,
            selectedId = selectedId,
            catFilter = catFilter,
            emFilter = emFilter
        )
    }.combine(_showCreateOrderSheet) { partial, showCreate ->
        partial.copy(showCreate = showCreate)
    }.combine(_showComplianceSheet) { partial, showCompliance ->
        partial.copy(showCompliance = showCompliance)
    }.combine(_showBidPlacementSheet) { partial, showBid ->
        partial.copy(showBid = showBid)
    }.combine(_lastActionMessage) { partial, actionMsg ->
        val filtered = partial.orders.filter { order ->
            val matchCat = partial.catFilter == null || order.category == partial.catFilter
            val matchEm = partial.emFilter == null || order.pickupEmirate == partial.emFilter || order.dropoffEmirate == partial.emFilter
            matchCat && matchEm
        }
        val selected = partial.orders.find { it.id == partial.selectedId }

        WaselUiState(
            currentRole = partial.role,
            orders = partial.orders,
            filteredOrders = filtered,
            selectedOrder = selected,
            selectedCategoryFilter = partial.catFilter,
            selectedEmirateFilter = partial.emFilter,
            currentDriver = repository.currentDriverProfile,
            showCreateOrderSheet = partial.showCreate,
            showComplianceSheet = partial.showCompliance,
            showBidPlacementSheet = partial.showBid,
            lastActionMessage = actionMsg
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = WaselUiState(currentDriver = repository.currentDriverProfile)
    )

    private data class WaselUiPartial(
        val orders: List<DeliveryOrder>,
        val role: UserRole,
        val selectedId: String?,
        val catFilter: OrderCategory?,
        val emFilter: Emirate?,
        val showCreate: Boolean = false,
        val showCompliance: Boolean = false,
        val showBid: Boolean = false
    )

    fun toggleRole() {
        val newRole = if (_currentRole.value == UserRole.MERCHANT) UserRole.DRIVER else UserRole.MERCHANT
        _currentRole.value = newRole
        _lastActionMessage.value = if (newRole == UserRole.MERCHANT) {
            "تم التحويل إلى وضع التاجر / العميل (إنشاء وإدارة الطلبيات)"
        } else {
            "تم التحويل إلى وضع السائق / المندوب (استعراض الطلبات والمزايدة التنافسية)"
        }
    }

    fun selectOrder(orderId: String?) {
        _selectedOrderId.value = orderId
    }

    fun setCategoryFilter(category: OrderCategory?) {
        _selectedCategoryFilter.value = category
    }

    fun setEmirateFilter(emirate: Emirate?) {
        _selectedEmirateFilter.value = emirate
    }

    fun openCreateOrderSheet() {
        _showCreateOrderSheet.value = true
    }

    fun closeCreateOrderSheet() {
        _showCreateOrderSheet.value = false
    }

    fun openComplianceSheet() {
        _showComplianceSheet.value = true
    }

    fun closeComplianceSheet() {
        _showComplianceSheet.value = false
    }

    fun clearActionMessage() {
        _lastActionMessage.value = null
    }

    fun createOrder(
        title: String,
        description: String,
        category: OrderCategory,
        pickupEmirate: Emirate,
        pickupLocation: String,
        dropoffEmirate: Emirate,
        dropoffLocation: String,
        targetPriceAed: Double,
        is247Express: Boolean
    ): String {
        val newOrder = repository.createOrder(
            title = title,
            description = description,
            category = category,
            pickupEmirate = pickupEmirate,
            pickupLocation = pickupLocation,
            dropoffEmirate = dropoffEmirate,
            dropoffLocation = dropoffLocation,
            targetPriceAed = targetPriceAed,
            is247Express = is247Express
        )
        _showCreateOrderSheet.value = false
        _selectedOrderId.value = newOrder.id
        _lastActionMessage.value = "تم نشر الطلب في سوق المزايدة المباشرة بنجاح!"
        return newOrder.id
    }

    fun openBidPlacementFor(orderId: String) {
        _selectedOrderId.value = orderId
        _showBidPlacementSheet.value = true
    }

    fun closeBidPlacement() {
        _showBidPlacementSheet.value = false
    }

    fun acceptBid(orderId: String, bidId: String) {
        repository.acceptBid(orderId, bidId)
        _lastActionMessage.value = "تم قبول العرض وقفل السعر والمسار بنجاح!"
    }

    fun advanceOrderStatus(orderId: String) {
        repository.advanceOrderStatus(orderId)
    }

    fun verifyPinAndDeliver(orderId: String, pin: String): Boolean {
        val success = repository.verifyPinAndDeliver(orderId, pin)
        if (success) {
            _lastActionMessage.value = "تم التحقق من الرمز السري بنجاح واكتمال التسليم!"
        } else {
            _lastActionMessage.value = "الرمز السري غير صحيح، يرجى التأكد من المستلم."
        }
        return success
    }

    fun placeDriverBid(orderId: String, amountAed: Double, etaMinutes: Int, noteAr: String) {
        repository.placeDriverBid(orderId, amountAed, etaMinutes, noteAr)
        _lastActionMessage.value = "تم إرسال عرض سعرك ($amountAed د.إ) إلى التاجر بنجاح!"
    }

    fun sendChatMessage(orderId: String, text: String) {
        val role = _currentRole.value
        val name = if (role == UserRole.MERCHANT) "صاحب الطلب" else repository.currentDriverProfile.nameAr
        repository.sendChatMessage(orderId, role, name, text)
    }

    fun calculateDynamicFloor(pickup: Emirate, dropoff: Emirate, category: OrderCategory): Double {
        val dist = repository.calculateDistanceKm(pickup, dropoff)
        val tolls = repository.calculateEstimatedTolls(pickup, dropoff)
        return repository.calculateDynamicFloorPrice(dist, tolls, category)
    }

    fun calculateDistance(pickup: Emirate, dropoff: Emirate): Int {
        return repository.calculateDistanceKm(pickup, dropoff)
    }

    fun calculateTolls(pickup: Emirate, dropoff: Emirate): Double {
        return repository.calculateEstimatedTolls(pickup, dropoff)
    }
}
