package com.example.data

import com.example.model.Bid
import com.example.model.BidStatus
import com.example.model.ChatMessage
import com.example.model.DeliveryOrder
import com.example.model.DriverProfile
import com.example.model.Emirate
import com.example.model.OrderCategory
import com.example.model.OrderStatus
import com.example.model.UserRole
import com.example.model.VehicleType
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.util.UUID
import kotlin.math.abs
import kotlin.random.Random

class WaselRepository {

    private val repositoryScope = CoroutineScope(Dispatchers.Default)

    // Current logged in driver profile for Driver Mode
    val currentDriverProfile = DriverProfile(
        id = "drv_me",
        nameAr = "كابتن سيف المري (أنت)",
        avatarLetter = "س",
        rating = 4.96,
        reviewsCount = 428,
        completedTripsCount = 1350,
        vehicleType = VehicleType.AC_SEDAN,
        vehiclePlate = "دبي B-88319",
        isAsateelVerified = true,
        phoneNumber = "+971501234567",
        acceptanceRate = 99
    )

    // Pool of verified UAE drivers for competitive bidding simulation
    val verifiedDrivers = listOf(
        DriverProfile(
            id = "drv_1",
            nameAr = "سلطان الكعبي",
            avatarLetter = "س",
            rating = 4.95,
            reviewsCount = 512,
            completedTripsCount = 1680,
            vehicleType = VehicleType.AC_SEDAN,
            vehiclePlate = "أبوظبي 5-41902",
            isAsateelVerified = true,
            phoneNumber = "+971509876543"
        ),
        DriverProfile(
            id = "drv_2",
            nameAr = "محمد راشد الزعابي",
            avatarLetter = "م",
            rating = 4.88,
            reviewsCount = 290,
            completedTripsCount = 890,
            vehicleType = VehicleType.COOLING_VAN,
            vehiclePlate = "دبي A-23411",
            isAsateelVerified = true,
            phoneNumber = "+971524455667"
        ),
        DriverProfile(
            id = "drv_3",
            nameAr = "طارق كمال",
            avatarLetter = "ط",
            rating = 4.91,
            reviewsCount = 640,
            completedTripsCount = 2150,
            vehicleType = VehicleType.INSULATED_BIKE,
            vehiclePlate = "الشارقة 3-1198",
            isAsateelVerified = true,
            phoneNumber = "+971556677889"
        ),
        DriverProfile(
            id = "drv_4",
            nameAr = "عبدالله المنصوري",
            avatarLetter = "ع",
            rating = 4.98,
            reviewsCount = 380,
            completedTripsCount = 1120,
            vehicleType = VehicleType.SUV_TRANSPORT,
            vehiclePlate = "أبوظبي 12-7788",
            isAsateelVerified = true,
            phoneNumber = "+971508899001"
        ),
        DriverProfile(
            id = "drv_5",
            nameAr = "سالم الظاهري",
            avatarLetter = "س",
            rating = 4.85,
            reviewsCount = 195,
            completedTripsCount = 540,
            vehicleType = VehicleType.AC_SEDAN,
            vehiclePlate = "العين 4-9012",
            isAsateelVerified = true,
            phoneNumber = "+971561122334"
        )
    )

    private val _orders = MutableStateFlow<List<DeliveryOrder>>(emptyList())
    val orders: StateFlow<List<DeliveryOrder>> = _orders.asStateFlow()

    init {
        initSampleOrders()
    }

    private fun initSampleOrders() {
        val sampleList = mutableListOf<DeliveryOrder>()

        // Order 1: Dates & Chocolates (Dubai to Abu Dhabi) - Temperature Sensitive
        val dist1 = calculateDistanceKm(Emirate.DUBAI, Emirate.ABU_DHABI)
        val tolls1 = calculateEstimatedTolls(Emirate.DUBAI, Emirate.ABU_DHABI)
        val floor1 = calculateDynamicFloorPrice(dist1, tolls1, OrderCategory.DATES_CHOCOLATE)
        val target1 = floor1 + 25.0

        val order1 = DeliveryOrder(
            id = "ord_uae_001",
            trackingCode = "WSL-7821-DXB",
            category = OrderCategory.DATES_CHOCOLATE,
            title = "صندوق تمور ملكية فاخرة وشوكولاتة بلجيكية",
            description = "شحنة حساسة للحرارة والصيف، تتطلب مركبة مكيفة أو فان تبريد لمنع الذوبان. التسليم لباب الفيلا مباشرة.",
            pickupEmirate = Emirate.DUBAI,
            pickupLocation = "ديرة - شارع المرقبات، متجر تمور الإمارات",
            dropoffEmirate = Emirate.ABU_DHABI,
            dropoffLocation = "البطين - مجمع القصور السكني، فيلا 14",
            distanceKm = dist1,
            estimatedTollsAed = tolls1,
            dynamicFloorPriceAed = floor1,
            merchantTargetPriceAed = target1,
            deliveryPin = "6294",
            is247Express = true,
            status = OrderStatus.WAITING_FOR_BIDS,
            createdAt = System.currentTimeMillis() - 1000 * 60 * 18,
            bids = listOf(
                Bid(
                    id = "bid_101",
                    orderId = "ord_uae_001",
                    driver = verifiedDrivers[0], // سلطان الكعبي (AC Sedan)
                    amountAed = target1, // Matches target!
                    etaMinutes = 20,
                    noteAr = "متاح فوراً، سيارة صالون مكيفة على أعلى درجة، مسجل في أساطيل أبوظبي."
                ),
                Bid(
                    id = "bid_102",
                    orderId = "ord_uae_001",
                    driver = verifiedDrivers[1], // محمد الزعابي (Cooling Van)
                    amountAed = target1 + 15.0,
                    etaMinutes = 15,
                    noteAr = "لدي فان تبريد مخصص للشوكولاتة بدرجة حرارة 18°C مضمونة طوال الطريق."
                ),
                Bid(
                    id = "bid_103",
                    orderId = "ord_uae_001",
                    driver = verifiedDrivers[3], // عبدالله المنصوري (SUV)
                    amountAed = target1 - 10.0,
                    etaMinutes = 35,
                    noteAr = "متجه إلى أبوظبي خلال نصف ساعة، عرض اقتصادي مع قفل السعر."
                )
            ),
            chatMessages = listOf(
                ChatMessage(
                    id = "msg_sys_1",
                    senderRole = UserRole.MERCHANT,
                    senderName = "النظام الذكي",
                    messageText = "تم بث طلبية التمور والشوكولاتة إلى مناديب وسائقي المركبات المكيفة فقط لحماية الجودة.",
                    isSystemNotice = true
                )
            )
        )

        // Order 2: Birds & Pets (Sharjah to Dubai) - Live animal safety
        val dist2 = calculateDistanceKm(Emirate.SHARJAH, Emirate.DUBAI)
        val tolls2 = calculateEstimatedTolls(Emirate.SHARJAH, Emirate.DUBAI)
        val floor2 = calculateDynamicFloorPrice(dist2, tolls2, OrderCategory.PETS_BIRDS)
        val target2 = floor2 + 15.0

        val order2 = DeliveryOrder(
            id = "ord_uae_002",
            trackingCode = "WSL-9043-SHJ",
            category = OrderCategory.PETS_BIRDS,
            title = "زوج طيور كروان أليفة مع قفص آمن",
            description = "طيور نادرة تحتاج هدوء تام وتكييف بارد وقيادة آمنة. يمنع منعاً باتاً النقل بالدراجات النارية.",
            pickupEmirate = Emirate.SHARJAH,
            pickupLocation = "مويلح التجارية - سوق الطيور والحيوانات",
            dropoffEmirate = Emirate.DUBAI,
            dropoffLocation = "ند الشبا 3 - مجمع الفلل",
            distanceKm = dist2,
            estimatedTollsAed = tolls2,
            dynamicFloorPriceAed = floor2,
            merchantTargetPriceAed = target2,
            deliveryPin = "4815",
            is247Express = true,
            status = OrderStatus.WAITING_FOR_BIDS,
            createdAt = System.currentTimeMillis() - 1000 * 60 * 35,
            bids = listOf(
                Bid(
                    id = "bid_201",
                    orderId = "ord_uae_002",
                    driver = verifiedDrivers[0],
                    amountAed = target2,
                    etaMinutes = 18,
                    noteAr = "سيارة صالون هادئة ومكيفة ومجهزة لتثبيت الأقفاص بحزام الأمان."
                ),
                Bid(
                    id = "bid_202",
                    orderId = "ord_uae_002",
                    driver = verifiedDrivers[3],
                    amountAed = target2 + 10.0,
                    etaMinutes = 25,
                    noteAr = "سيارة SUV رحبة، تعامل احترافي مع الطيور والحيوانات الأليفة."
                )
            )
        )

        // Order 3: Luxury Perfumes & Gift (Abu Dhabi to Dubai) - In transit
        val dist3 = calculateDistanceKm(Emirate.ABU_DHABI, Emirate.DUBAI)
        val tolls3 = calculateEstimatedTolls(Emirate.ABU_DHABI, Emirate.DUBAI)
        val floor3 = calculateDynamicFloorPrice(dist3, tolls3, OrderCategory.GIFTS_PERFUMES)
        val agreed3 = floor3 + 20.0

        val order3 = DeliveryOrder(
            id = "ord_uae_003",
            trackingCode = "WSL-3312-AUH",
            category = OrderCategory.GIFTS_PERFUMES,
            title = "طقم عطور دهن عود وباقة زهور VIP",
            description = "هدية عيد ميلاد ثمينة، التسليم برمز التحقق الرباعي PIN لضمان استلام الشخص المعني شخصياً.",
            pickupEmirate = Emirate.ABU_DHABI,
            pickupLocation = "جزيرة المارية - الغاليريا مول، بوتيك خصلة للعطور",
            dropoffEmirate = Emirate.DUBAI,
            dropoffLocation = "داون تاون دبي - برج بوليفارد بوينت",
            distanceKm = dist3,
            estimatedTollsAed = tolls3,
            dynamicFloorPriceAed = floor3,
            merchantTargetPriceAed = agreed3,
            agreedPriceAed = agreed3,
            deliveryPin = "8305",
            is247Express = true,
            status = OrderStatus.IN_TRANSIT,
            createdAt = System.currentTimeMillis() - 1000 * 60 * 75,
            selectedDriver = verifiedDrivers[0],
            bids = listOf(
                Bid(
                    id = "bid_301",
                    orderId = "ord_uae_003",
                    driver = verifiedDrivers[0],
                    amountAed = agreed3,
                    etaMinutes = 45,
                    noteAr = "تم الاتفاق وقفل السعر والمسار. في طريقي للوجهة الآن.",
                    status = BidStatus.ACCEPTED
                )
            ),
            chatMessages = listOf(
                ChatMessage(
                    id = "m1",
                    senderRole = UserRole.MERCHANT,
                    senderName = "متجر خصلة",
                    messageText = "مرحباً كابتن سلطان، الهدية مغلفة بأناقة مع باقة الورد، نرجو الحذر أثناء القيادة."
                ),
                ChatMessage(
                    id = "m2",
                    senderRole = UserRole.DRIVER,
                    senderName = "سلطان الكعبي",
                    messageText = "أهلاً وسهلاً، تم تثبيتها بالمقعد الخلفي المكيف، وتجاوزت جسر الشيخ زايد باتجاه دبي."
                ),
                ChatMessage(
                    id = "m3",
                    senderRole = UserRole.MERCHANT,
                    senderName = "متجر خصلة",
                    messageText = "ممتاز جداً! رمز التحقق PIN تم إرساله للمستلم وسيزودك به عند باب البرج."
                )
            )
        )

        // Order 4: Food & Meals (Ajman to Sharjah) - Fast bike/car
        val dist4 = calculateDistanceKm(Emirate.AJMAN, Emirate.SHARJAH)
        val tolls4 = calculateEstimatedTolls(Emirate.AJMAN, Emirate.SHARJAH)
        val floor4 = calculateDynamicFloorPrice(dist4, tolls4, OrderCategory.FOOD_MEALS)
        val target4 = floor4 + 5.0

        val order4 = DeliveryOrder(
            id = "ord_uae_004",
            trackingCode = "WSL-5120-AJM",
            category = OrderCategory.FOOD_MEALS,
            title = "وجبات عشاء مطبخ خليجي ساخن لـ 5 أشخاص",
            description = "أطعمة ساخنة تتطلب حقيبة توصيل حرارية معزولة وتوصيل مباشر بدون تأخير.",
            pickupEmirate = Emirate.AJMAN,
            pickupLocation = "الكورنيش - مطعم المند والمظبي الملكي",
            dropoffEmirate = Emirate.SHARJAH,
            dropoffLocation = "الخالدية - شارع الميناء، بناية الهدى",
            distanceKm = dist4,
            estimatedTollsAed = tolls4,
            dynamicFloorPriceAed = floor4,
            merchantTargetPriceAed = target4,
            deliveryPin = "1923",
            is247Express = true,
            status = OrderStatus.WAITING_FOR_BIDS,
            createdAt = System.currentTimeMillis() - 1000 * 60 * 8,
            bids = listOf(
                Bid(
                    id = "bid_401",
                    orderId = "ord_uae_004",
                    driver = verifiedDrivers[2], // طارق كمال (Bike with insulated box)
                    amountAed = target4,
                    etaMinutes = 12,
                    noteAr = "صندوق حراري فايبرجلاس معزول مخصص للأطعمة الساخنة. وصول خلال 12 دقيقة."
                )
            )
        )

        sampleList.add(order1)
        sampleList.add(order2)
        sampleList.add(order3)
        sampleList.add(order4)

        _orders.value = sampleList
    }

    fun calculateDistanceKm(pickup: Emirate, dropoff: Emirate): Int {
        if (pickup == dropoff) return 18 // Intra-city average
        val diff = abs(pickup.baseKmFromDubai - dropoff.baseKmFromDubai)
        return if (diff == 0) 25 else diff
    }

    fun calculateEstimatedTolls(pickup: Emirate, dropoff: Emirate): Double {
        var toll = 0.0
        // Salik in Dubai (4 AED off-peak, 6 AED peak)
        if (pickup == Emirate.DUBAI || dropoff == Emirate.DUBAI) {
            toll += 8.0 // Approx 2 gates round/trip
        }
        // Darb in Abu Dhabi (4 AED during peak)
        if (pickup == Emirate.ABU_DHABI || dropoff == Emirate.ABU_DHABI || pickup == Emirate.AL_AIN || dropoff == Emirate.AL_AIN) {
            toll += 4.0
        }
        // Sharjah/Dubai border
        if ((pickup == Emirate.SHARJAH && dropoff == Emirate.DUBAI) || (pickup == Emirate.DUBAI && dropoff == Emirate.SHARJAH)) {
            toll += 4.0
        }
        return toll
    }

    // Dynamic Price Floor to eliminate "Winner's curse" as outlined in research
    fun calculateDynamicFloorPrice(distanceKm: Int, tollsAed: Double, category: OrderCategory): Double {
        val baseStartingFare = 20.0
        val perKmRate = when {
            distanceKm > 100 -> 0.85 // Discounted per km for inter-emirate long distance
            distanceKm > 50 -> 0.95
            else -> 1.15
        }
        val distanceCost = distanceKm * perKmRate

        val categorySurcharge = when (category) {
            OrderCategory.PETS_BIRDS -> 20.0 // Special pet handling, safety care
            OrderCategory.DATES_CHOCOLATE -> 15.0 // Cooling/AC vehicle requirement
            OrderCategory.GIFTS_PERFUMES -> 10.0 // Extra handling, gift card, PIN
            else -> 0.0
        }

        val total = baseStartingFare + distanceCost + tollsAed + categorySurcharge
        return (total.toInt() / 5 * 5).toDouble().coerceAtLeast(25.0) // Rounded to neat step
    }

    fun createOrder(
        title: String,
        description: String,
        category: OrderCategory,
        pickupEmirate: Emirate,
        pickupLocation: String,
        dropoffEmirate: Emirate,
        dropoffLocation: String,
        targetPriceAed: Double,
        is247Express: Boolean
    ): DeliveryOrder {
        val dist = calculateDistanceKm(pickupEmirate, dropoffEmirate)
        val tolls = calculateEstimatedTolls(pickupEmirate, dropoffEmirate)
        val floor = calculateDynamicFloorPrice(dist, tolls, category)
        val randomPin = (1000..9999).random().toString()
        val randomCode = "WSL-${(1000..9999).random()}-${pickupEmirate.name.take(3)}"

        val finalTarget = targetPriceAed.coerceAtLeast(floor)

        val newOrder = DeliveryOrder(
            id = "ord_" + UUID.randomUUID().toString().take(8),
            trackingCode = randomCode,
            category = category,
            title = title,
            description = description,
            pickupEmirate = pickupEmirate,
            pickupLocation = pickupLocation,
            dropoffEmirate = dropoffEmirate,
            dropoffLocation = dropoffLocation,
            distanceKm = dist,
            estimatedTollsAed = tolls,
            dynamicFloorPriceAed = floor,
            merchantTargetPriceAed = finalTarget,
            deliveryPin = randomPin,
            is247Express = is247Express,
            status = OrderStatus.WAITING_FOR_BIDS,
            createdAt = System.currentTimeMillis(),
            chatMessages = listOf(
                ChatMessage(
                    id = UUID.randomUUID().toString(),
                    senderRole = UserRole.MERCHANT,
                    senderName = "النظام",
                    messageText = "تم إنشاء الطلبية بنجاح وبثها في سوق المزايدة اللحظية للسائقين المؤهلين.",
                    isSystemNotice = true
                )
            )
        )

        val currentList = _orders.value.toMutableList()
        currentList.add(0, newOrder)
        _orders.value = currentList

        // Trigger simulated realistic competitive bids from nearby drivers
        simulateIncomingBids(newOrder.id, finalTarget, category)

        return newOrder
    }

    private fun simulateIncomingBids(orderId: String, targetPrice: Double, category: OrderCategory) {
        repositoryScope.launch {
            delay(1500)
            val eligibleDrivers = verifiedDrivers.filter { driver ->
                if (category.requiresAC) driver.vehicleType.isClimateControlled else true
            }.shuffled().take(2)

            for ((index, driver) in eligibleDrivers.withIndex()) {
                delay((index + 1) * 1200L)
                val variance = when (index) {
                    0 -> 0.0 // Matches target exactly
                    1 -> (Random.nextInt(1, 4) * 5).toDouble() // +5, +10, or +15
                    else -> -(Random.nextInt(1, 3) * 5).toDouble() // discount
                }
                val bidAmt = (targetPrice + variance).coerceAtLeast(25.0)
                val note = when (driver.vehicleType) {
                    VehicleType.AC_SEDAN -> "سيارة صالون مكيفة، متاح فوراً للتحرك والتوصيل."
                    VehicleType.COOLING_VAN -> "فان مبرد بدرجة حرارة محكمة، مناسب جداً للبضاعة."
                    VehicleType.INSULATED_BIKE -> "دراجة سريعة بصندوق عازل حرارياً معتمد."
                    VehicleType.SUV_TRANSPORT -> "سيارة دفع رباعي رحبة وسريعة، كابتن موثق أساطيل."
                }
                val newBid = Bid(
                    id = "bid_" + UUID.randomUUID().toString().take(6),
                    orderId = orderId,
                    driver = driver,
                    amountAed = bidAmt,
                    etaMinutes = Random.nextInt(10, 30),
                    noteAr = note
                )

                val updatedList = _orders.value.map { order ->
                    if (order.id == orderId && order.status == OrderStatus.WAITING_FOR_BIDS) {
                        order.copy(bids = order.bids + newBid)
                    } else order
                }
                _orders.value = updatedList
            }
        }
    }

    fun acceptBid(orderId: String, bidId: String) {
        val updatedList = _orders.value.map { order ->
            if (order.id == orderId) {
                val chosenBid = order.bids.find { it.id == bidId }
                if (chosenBid != null) {
                    val updatedBids = order.bids.map {
                        if (it.id == bidId) it.copy(status = BidStatus.ACCEPTED)
                        else it.copy(status = BidStatus.REJECTED)
                    }
                    val lockNotice = ChatMessage(
                        id = UUID.randomUUID().toString(),
                        senderRole = UserRole.MERCHANT,
                        senderName = "نظام قفل السعر والمسار",
                        messageText = "تم قبول عرض الكابتن ${chosenBid.driver.nameAr} بقيمة ${chosenBid.amountAed} د.إ. تم قفل السعر والمسار برمجياً منعاً لأي تغيير.",
                        isSystemNotice = true
                    )
                    order.copy(
                        status = OrderStatus.BID_ACCEPTED,
                        selectedDriver = chosenBid.driver,
                        agreedPriceAed = chosenBid.amountAed,
                        bids = updatedBids,
                        chatMessages = order.chatMessages + lockNotice
                    )
                } else order
            } else order
        }
        _orders.value = updatedList
    }

    fun advanceOrderStatus(orderId: String) {
        val updatedList = _orders.value.map { order ->
            if (order.id == orderId) {
                val nextStatus = when (order.status) {
                    OrderStatus.BID_ACCEPTED -> OrderStatus.DRIVER_EN_ROUTE_PICKUP
                    OrderStatus.DRIVER_EN_ROUTE_PICKUP -> OrderStatus.PICKED_UP
                    OrderStatus.PICKED_UP -> OrderStatus.IN_TRANSIT
                    OrderStatus.IN_TRANSIT -> OrderStatus.DELIVERED
                    else -> order.status
                }
                val statusMsg = ChatMessage(
                    id = UUID.randomUUID().toString(),
                    senderRole = UserRole.DRIVER,
                    senderName = order.selectedDriver?.nameAr ?: "الكابتن",
                    messageText = "تحديث الحالة: ${nextStatus.titleAr}",
                    isSystemNotice = true
                )
                order.copy(status = nextStatus, chatMessages = order.chatMessages + statusMsg)
            } else order
        }
        _orders.value = updatedList
    }

    fun verifyPinAndDeliver(orderId: String, enteredPin: String): Boolean {
        val order = _orders.value.find { it.id == orderId } ?: return false
        if (order.deliveryPin == enteredPin.trim()) {
            val updatedList = _orders.value.map {
                if (it.id == orderId) {
                    val successMsg = ChatMessage(
                        id = UUID.randomUUID().toString(),
                        senderRole = UserRole.MERCHANT,
                        senderName = "نظام الأمان والضمان",
                        messageText = "تم إدخال رمز التحقق ($enteredPin) بنجاح! تم تحرير مستحقات الكابتن واكتمال الرحلة.",
                        isSystemNotice = true
                    )
                    it.copy(status = OrderStatus.DELIVERED, chatMessages = it.chatMessages + successMsg)
                } else it
            }
            _orders.value = updatedList
            return true
        }
        return false
    }

    // Used by driver mode to place a competitive bid on any order
    fun placeDriverBid(orderId: String, amountAed: Double, etaMinutes: Int, noteAr: String) {
        val driverBid = Bid(
            id = "bid_my_" + UUID.randomUUID().toString().take(6),
            orderId = orderId,
            driver = currentDriverProfile,
            amountAed = amountAed,
            etaMinutes = etaMinutes,
            noteAr = noteAr.ifBlank { "كابتن معتمد، جاهز للتنفيذ فوراً باحترافية وتكييف عالي." }
        )
        val updatedList = _orders.value.map { order ->
            if (order.id == orderId) {
                order.copy(bids = order.bids + driverBid)
            } else order
        }
        _orders.value = updatedList
    }

    fun sendChatMessage(orderId: String, senderRole: UserRole, senderName: String, text: String) {
        if (text.isBlank()) return
        val newMsg = ChatMessage(
            id = UUID.randomUUID().toString(),
            senderRole = senderRole,
            senderName = senderName,
            messageText = text.trim()
        )
        val updatedList = _orders.value.map { order ->
            if (order.id == orderId) {
                order.copy(chatMessages = order.chatMessages + newMsg)
            } else order
        }
        _orders.value = updatedList
    }
}
